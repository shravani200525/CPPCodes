//default values to constructor 
//right to left->compulsory

#include<iostream>
class demo
{
    int n1=10;
    int n2=20;
    public:
    demo(int n1=30,n2)
    {
        this->n1=n1;
        this->n2=n2;
    }
    void getinfo(int n3,int n4)
    {
        n1 = n3;
        n2= n4;
        std::cout<< n1 << std::endl;
        std::cout<< n2 << std::endl;
    }
};
int main()
{
    int n1,n2;
    std::cout<< "enter values"<<std::endl;
    std::cin>>n1>>n2;
    demo obj(n1,n2);
}
/*
output
error: ‘n2’ is not a type
   10 |     demo(int n1=30,n2)
      |                    ^~
program1.cpp:10:20: error: default argument missing for parameter 2 of ‘demo::demo(int, int)’
*/