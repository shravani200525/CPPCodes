//passing 200 to constructor but there are 2 parameters 
//assignemnt right to left ,therefor 200 will be assign to n1

#include <iostream>
class Demo{
    int n1 = 10;
    int n2 = 20;

    public:
        Demo(){
            std::cout <<"No-arg-constructor"<<std::endl;
        }
        Demo(int n1=20,int n2=30){
            this->n1 = n1;
            this->n2 = n2;
            std::cout << "para construct"<<std::endl;
        }
        void getInfo(){
            std::cout<< n1 << std::endl;
            std::cout<< n2 << std::endl;
        }
};
int main(){
 
    Demo obj1(200);
    obj1.getInfo();
    return(0);
}
/*para construct
200
30*/