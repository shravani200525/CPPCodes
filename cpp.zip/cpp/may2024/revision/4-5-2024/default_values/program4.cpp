//default values to constructor
//default values given, but does not pass arguments
//no arg-constructor is there,therefore ambiquity

#include<iostream>
class demo
{
    int n1=10;
    int n2=20;

    public:
        demo()
        {
            std::cout<<"no argument constructor"<<std::endl;
        }
        demo(int n1=20,int n2=30)
        {
            this->n1 = n1;
            this->n2 = n2;
            std::cout << "para construct"<<std::endl;

        }
        void getInfo(){
            std::cout<< n1 << std::endl;
            std::cout<< n2 << std::endl;
        }

};
int main(){
 
    demo obj1;
    obj1.getInfo();
    return(0);
}
/*output
error: call of overloaded ‘demo()’ is ambiguous
   31 |     demo obj1;
      |          ^~~~
*/
