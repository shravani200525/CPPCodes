//default values to constructor
//default values given,but does not pass argument

#include<iostream>
class demo
{
    int n1 = 10;
    int n2=20;

    public:
        demo(int n1=100,int n2=300)
        {
            this->n1=n1;
            this->n2=n2;
            std::cout<<"parameterized constructor"<<std::endl;
        }
        void getinfo()
        {
            std::cout<< n1 << std::endl;
            std:: cout << n2 << std::endl;
        }
};
int main()
{
    demo obj1;
    obj1.getinfo();
}
/*
output
parameterized constructor
100
300
*/