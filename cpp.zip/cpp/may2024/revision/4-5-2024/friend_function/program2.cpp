//one function friend 
//object send to friend function is not const,so 
//from inside private and protected can be changed

#include <iostream>
class Demo{
    int n1 = 10;

    protected:
    int n2 = 20;

    public:
        Demo(){
            std::cout <<"constructor "<<std::endl;
        }
        void getInfo(){
            std::cout << n1 << std::endl;
            std::cout << n2 << std::endl;
        }
        friend void displayData(Demo& obj);
};
void displayData(Demo& obj){
    obj.n1 = 500;
    obj.n2 = 600;
    std::cout <<obj.n1 << std::endl;
    std::cout <<obj.n2 << std::endl;
}
int main(){
    Demo obj;

    displayData(obj);
    
    return(0);
}
/*output
constructor
500
600*/