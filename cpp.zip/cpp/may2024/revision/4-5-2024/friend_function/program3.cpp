//one function friend 
//object send to friend function is not const,so 
//from inside private and procted can be changed 
//to avoid it make object const ->error 

#include <iostream>
class Demo{
    int n1 = 10;

    protected:
    int n2 = 20;

    public:
        Demo(){
            std::cout <<"constructor "<<std::endl;
        }
        void getInfo(){
            std::cout << n1 << std::endl;
            std::cout << n2 << std::endl;
        }
        friend void displayData(const Demo& obj);
};
void displayData(const Demo& obj){
    obj.n1 = 500;
    obj.n2 = 600;
    std::cout <<obj.n1 << std::endl;
    std::cout <<obj.n2 << std::endl;
}
int main(){
    Demo obj;

    displayData(obj);
    return(0);
}
/*
error: assignment of member ‘Demo::n1’ in read-only object
   24 |     obj.n1 = 500;
      |     ~~~~~~~^~~~~
program3.cpp:25:12: error: assignment of member ‘Demo::n2’ in read-only object
   25 |     obj.n2 = 600;
      |     ~~~~~~~^~~~~
*/