//make whole friend 
//calling getInfo() method 

#include <iostream>
class DemoTwo;
class DemoOne{

    int n1 = 10;

    protected:
    int n2 = 20;

    public:
        DemoOne(){
            std::cout <<"DemoOne Constructor"<<std::endl;
        }
        friend class DemoTwo;
};
class DemoTwo{
    public:
        DemoTwo(){
            std::cout <<"DemoTwo Constructor" <<std::endl;
        }
    private:
        void getInfo(const DemoOne& obj){
            std::cout <<obj.n1 <<std::endl;
            std::cout <<obj.n1 << std::endl;
        }
    public:
        void accessData(const DemoOne& obj){
            std::cout << obj.n1 << std::endl;
            std::cout << obj.n2 << std::endl;
            getInfo(obj);
        }
};
int main(){
    DemoOne obj1;
    DemoTwo obj2;

    obj2.accessData(obj1);
    return(0);
}
/*DemoOne Constructor
DemoTwo Constructor
10
20
10
10*/