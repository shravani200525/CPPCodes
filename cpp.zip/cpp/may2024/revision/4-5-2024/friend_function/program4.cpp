//two class friend of one function 
//const error for getData()

class DemoTwo;//forward declaraion
#include <iostream>

class DemoOne {
    int n1 = 10;

    protected:
    int n2 =20;

    public:
        DemoOne(){
            std::cout<<"Constructor "<<std::endl;
        }
    private:
        void getInfo()const{
            std::cout <<"n1 = "<< n1 << std::endl;
            std::cout <<"n2 = "<<n2 << std::endl;
        }
        friend void displayData(const DemoOne& obj1,const DemoTwo& obj2);
};
class DemoTwo{

    int n3 = 40;
    protected:
    int n4 = 50;

    public:
        DemoTwo(){
            std::cout <<"Two Constructor "<<std::endl;
        }
        private:
            void getInfo()const{
                std::cout << "n3 = "<<n3 <<std::endl;
                std::cout << "n4 = "<<n4 <<std::endl;
            }
            friend void displayData(const DemoOne& obj1,const DemoTwo& obj2);
};
void displayData(const DemoOne& obj1,const DemoTwo& obj2){
    obj1.getInfo();
    obj2.getInfo();
}
int main(){
    DemoOne obj1;
    DemoTwo obj2;

    displayData(obj1,obj2);

}
/*Constructor
Two Constructor
n1 = 10
n2 = 20
n3 = 40
n4 = 50*/