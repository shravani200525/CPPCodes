//one function friend 
// private and protected variable specifically displayData() functon 
// accesed,don't make it public

#include<iostream>
class demo
{
    int n1=10;
    protected:
    int n2=20;
    public:
    demo()
    {
        std::cout<<"constructor"<<std::endl;

    }
    void getinfo()
    {
        std::cout<< n1 << std::endl;
        std::cout<< n2 << std::endl;
    }
    friend void displayData(demo& obj);
};
void displayData(demo& obj)
{
    std::cout<< obj.n1 << std::endl;
    std::cout << obj.n2 << std::endl;
}
int main()
{
    demo obj;
    displayData(obj);
}
/*output
constructor
10
20*/