//3rd way cpp17
// static inline -> compiler will consider it as const 

#include <iostream>
class Demo{
    int n1 = 10;
    static inline int n2 = 20;//static const 
};

int main(){

    return(0);
}