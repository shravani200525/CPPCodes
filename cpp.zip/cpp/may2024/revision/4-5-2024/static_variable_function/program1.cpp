//1st way static 
//declare inside class but initialize at global namespace 

#include <iostream>
class Demo{
    int n1 = 10;
    static int n2;//static declaration

};
int Demo::n2 = 20;

int main(){

    return(0);
}