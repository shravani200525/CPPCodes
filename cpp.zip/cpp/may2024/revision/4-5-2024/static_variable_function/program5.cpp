//static method and instance method 
//calling instace method 

#include <iostream>

class Demo{
    int n1 = 10;
    static int n2;

    public:
    void getInfo(){
        std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;
    }
    static void info(){

    }
};
int Demo :: n2 = 20;
int main(){
    Demo obj;
    obj.getInfo();

    return(0);
}
/*10
20*/