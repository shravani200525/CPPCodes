//error non-static method can't be call from static 
#include <iostream>

class Demo{
    int n1 = 10;
    static int n2;

    public:
    void getInfo(){
        std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;
    }
    static void getDetails(){
        // std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;
        getInfo();//error non-static cann't be call from static 

    }
};
int Demo :: n2 = 20;
int main(){
    Demo obj;
    obj.getInfo();

    obj.getDetails();
    Demo::getDetails();
    return(0);
}
/*error: cannot call member function ‘void Demo::getInfo()’ without object
   16 |         getInfo();//error non-static cann't be call from static
      |         ~~~~~~~^~
*/