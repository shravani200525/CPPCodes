// static method -> instance variable can't be accessed inside static method 
#include <iostream>

class Demo{
    int n1 = 10;
    static int n2;

    public:
    void getInfo(){
        std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;
    }
    static void getDetails(){
        std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;

    }
};
int Demo :: n2 = 20;
int main(){
    Demo obj;
    obj.getInfo();

    return(0);
}
/* error: invalid use of member ‘Demo::n1’ in static member function
   14 |         std::cout << n1 << std::endl;
      |                      ^~
program6.cpp:5:9: note: declared here
    5 |     int n1 = 10;
      |         ^~
*/