//Demonstrating following in single code 
// instance variable 
// static variable 
// instance method 
// static method 
//local static variable 
//local instance variable 

//static variable can't be initialize inside class 
//but they can be initialize inside static and non-static function 
#include <iostream>

class Demo{

    int n1 = 10;
    static int n2;

    public:
        void nonStaticFun(){
            int n3 = 30;
            static int n4 = 40;
        
            std::cout << n1 << std::endl;
            std::cout << n2 << std::endl;
            std::cout << n3 << std::endl;
            std::cout << n4 << std::endl;
        }
        static void staticFun(){
            int n5 = 50;
            static int n6 = 60;

            // std::cout << n1 <<std::endl;
            std::cout << n2 << std::endl;
            std::cout << n5 << std::endl;
            std::cout << n6 << std::endl;
        }
};
int Demo::n2 = 20;
int main(){
    Demo obj1;//1st way object creation ->stack
    Demo *obj2 = new Demo();//2nd way object creation->heap

    obj1.nonStaticFun();
    obj1.staticFun();

    obj2->nonStaticFun();
    obj2->staticFun();
}
/*10
20
30
40
20
50
60
10
20
30
40
20
50
60*/