//changing static -> change reflect on all objects 
//accessing static on class name
#include <iostream>

class Demo {
    int n1 = 10;
    public:
    static int n2;

};
int Demo:: n2 = 20;

int main(){
    Demo obj1;
    Demo obj2;

    // std::cout << Demo:: n1 << std::endl;//instance cann't access on class name

    obj2.n2 = 20;//static change,will reflect on all objects 

    std::cout << Demo::n2 << std::endl;//accessing static on class name 
    std::cout << obj1.n2 << std::endl;
    std::cout << obj2.n2 << std::endl;
}
/*20
20
20*/