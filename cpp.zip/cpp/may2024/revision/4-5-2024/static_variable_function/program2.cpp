
//2nd way static 
//static const nobody can change it 
//even each object got different copy,but nobody can change it,
//so it's like common to all
#include <iostream>
class Demo{
    int n1 = 10;
    static const int n2 = 20;//static const 
};

int main(){

    return(0);
}