//calling static method on object and class name =>allowed

#include <iostream>

class Demo{
    int n1 = 10;
    static int n2;

    public:
    void getInfo(){
        std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;
    }
    static void getDetails(){
        // std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;

    }
};
int Demo :: n2 = 20;
int main(){
    Demo obj;
    obj.getInfo();

    obj.getDetails();
    Demo::getDetails();
    return(0);
}
/*10
20
20
20*/