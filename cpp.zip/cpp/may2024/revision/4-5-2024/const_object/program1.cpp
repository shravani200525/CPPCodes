/*const object*/
//object is const->so can't call and change variable from 
//outside class on object 
#include <iostream>

class Demo {
    public:
    int n1 = 10;

    Demo(){
        std::cout <<"No-arg-Constructor"<<std::endl;
    }
    void getData(){
        std::cout <<n1 << std::endl;
    }
};
int main(){

    const Demo obj;
    obj.getData();

    obj.n1 = 50;
    obj.getData();
    return(0);
}
/*
output
In function ‘int main()’:
program1.cpp:20:16: error: passing ‘const Demo’ as ‘this’ argument discards qualifiers [-fpermissive]
   20 |     obj.getData();
      |     ~~~~~~~~~~~^~
program1.cpp:13:10: note:   in call to ‘void Demo::getData()’
   13 |     void getData(){
      |          ^~~~~~~
program1.cpp:22:12: error: assignment of member ‘Demo::n1’ in read-only object
   22 |     obj.n1 = 50;
      |     ~~~~~~~^~~~
program1.cpp:23:16: error: passing ‘const Demo’ as ‘this’ argument discards qualifiers [-fpermissive]
   23 |     obj.getData();
      |     ~~~~~~~~~~~^~
program1.cpp:13:10: note:   in call to ‘void Demo::getData()’
   13 |     void getData(){
      |          ^~~~~~~
*/