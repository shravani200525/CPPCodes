 /*const object*/
//inside const function can't change n1 
#include <iostream>

class Demo {
    public:
    int n1 = 10;

    Demo(){
        this->n1 = 80;
        std::cout <<"No-arg-Constructor"<<std::endl;
    }
     void getData()const {
        this->n1 = 50;
        std::cout <<n1 << std::endl;
    }
};
int main(){

    const Demo obj;
    std::cout << obj.n1 << std::endl;
    obj.getData();

    // obj.n1 = 50;
    // obj.getData();
    return(0);
}
/*
output
error: assignment of member ‘Demo::n1’ in read-only object
   14 |         this->n1 = 50;
      |         ~~~~~~~~~^~~~
*/