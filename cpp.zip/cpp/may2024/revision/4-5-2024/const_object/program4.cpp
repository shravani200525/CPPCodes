/*const object*/
//object is const so ,function must be const 

#include <iostream>

class Demo {
    public:
    int n1 = 10;

    Demo(){
        this->n1 = 80;
        std::cout <<"No-arg-Constructor"<<std::endl;
    }
    void getData(){
        std::cout <<n1 << std::endl;
    }
};
int main(){

    const Demo obj;
    std::cout << obj.n1 << std::endl;
    obj.getData();

    // obj.n1 = 50;
    // obj.getData();
    return(0);
}
//output:
 //error: passing ‘const Demo’ as ‘this’ argument discards qualifiers [-fpermissive]
//22 |     obj.getData();
//  |     ~~~~~~~~~~~^~