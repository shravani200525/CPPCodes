/*const object*/
//object is const so ,function must be const 
//const before datatype->that is return type is const 
#include <iostream>

class Demo {
    public:
    int n1 = 10;

    Demo(){
        this->n1 = 80;
        std::cout <<"No-arg-Constructor"<<std::endl;
    }
     void getData()const {
        std::cout <<n1 << std::endl;
    }
};
int main(){

    const Demo obj;
    std::cout << obj.n1 << std::endl;
    obj.getData();

    // obj.n1 = 50;
    // obj.getData();
    return(0);
}
/*
output
No-arg-Constructor
80
80
*/