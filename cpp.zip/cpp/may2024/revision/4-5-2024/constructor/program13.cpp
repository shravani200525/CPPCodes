//3rd scenerio->copy constructor 
//passing object to function 
//copy constructor call

#include <iostream>
class Demo{

    int n1 = 10;
    int n2 = 20;

    public:
        Demo(){
            std::cout <<"No-argument-Constructor"<<std::endl;
            std::cout << n1<<std::endl;
            std::cout<< n2 << std::endl;
        }
        Demo(int n1,int n2){
            this->n1 = n1;
            this->n2 = n2;
            std::cout << "Parameterized constructor"<<std::endl;
            std::cout << n1 << std::endl;
            std::cout<< n2 << std::endl;
        }
        void getInfo(Demo obj){
            std::cout << n1 << std::endl;
            std::cout<< n2 << std::endl;
            std::cout << obj.n1<<std::endl;
            std::cout<<obj.n2 <<std::endl;
        }
        Demo(Demo& ref){
            std::cout <<"Copy Constructor "<<std::endl;
        }
     
};
int main(){
    Demo obj1;
    Demo obj2(100,200);

    obj2.getInfo(obj1);//copy constructor 
}
/*output:
No-argument-Constructor
10
20
Parameterized constructor
100
200
Copy Constructor
100
200
10
20
*/