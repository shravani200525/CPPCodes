//calling parameterized constructor from no-arg-constructor 
//using this() ->not allowed 
#include <iostream>

class Demo{
    public:
    int n1 = 10;
    
    Demo(){
        this(10);
        std::cout <<"no-arg constructor"<<std::endl;
    }
    Demo(int n1){
        std::cout <<"Parameterized Constructor"<<std::endl;
    }
    Demo(Demo& obj){
        std::cout <<"Copy Constructor" <<std::endl;
    }
    void getInfo(){
        std::cout << n1 << std::endl;
        std::cout <<this->n1<< std::endl;
    }
};
int main(){
    Demo obj1;

    return(0);
}
/* error: expression cannot be used as a function
    this(10);
*/