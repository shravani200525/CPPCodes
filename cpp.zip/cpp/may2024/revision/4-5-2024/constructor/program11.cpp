//1st scenerio->copy constrcutor inside main method 

#include<iostream>
class demo{
    //instance variable

    int n1=10;
    int n2=20;

    public:
    //no argument constructor
    demo()
    {
        std::cout<<"in no argument constructor"<<std::endl;
    }
    //copy constructor
    demo(demo& ref)
    {
        std::cout << "copy constructor"<<std::endl;
    }
    //member function
    void fun()
    {
        std::cout << n1 << std::endl;
        std::cout<<n2 << std::endl;
    }
};
//main function

int main()
{
    //object creation
    demo obj; //call no argument constructor
    demo obj2(obj); // call copy constructor
    obj.fun(); // call member function
}
/*in no argument constructor
copy constructor
10
20*/

//output:
/*
in no argument constructor
parameterized constructor
copy constructor
10
20
*/