//you written parameterized constructor 
//so you must write default also.

#include<iostream>
class demo
{
    int n1=10;
    int n2=20;
    public:
    //no argument constructor
    demo()
    {
        std::cout<<"in no argument constructor"<<std::endl;
    }
    //parameterized constructor
    demo(int n1,int n2)
    {
        std::cout<< "in parameterized constructor"<<std::endl;
    }
    //copy constructor
    demo(demo& obj){
        std::cout<<"in copy constructor"<<std::endl;
    }
    //member function
    void fun()
    {
        std::cout<< n1<< std::endl;
        std::cout<<n2<<std::endl;
    }
};

//main function
int main()
{
    //object
    demo obj1; //call no argument constructor
    demo obj2(10,20);//call parameterized constructor
    demo obj3(obj1); //call copy constructor
    obj1.fun();
}
/*
output:
in no argument constructor
in parameterized constructor
in copy constructor
10
20*/