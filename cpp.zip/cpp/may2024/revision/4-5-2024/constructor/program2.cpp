    //why to use 
    //1.no-argument constructor 
    //->to initialize instance variable of class ,
    //we use no-argument constructor 

    #include<iostream>
    class demo{
        
        //instance variable
        int n1=10;
        int n2=20;

        public:
        // no argument constructor
        demo()
        {
            std::cout<<"in no argument constructor" << std::endl;
            this->n1=10;
            this->n2=20;
            std::cout<< n1 << std::endl;
            std::cout<< n2 << std::endl;
        }
    };

    //main function

    int main()
    {
        //object creation
        demo obj; //call no argument constructor

        return(0);
    }
    /*
    output:
    in no argument constructor
    10
    20
    */




