//calling no-arg-Constructor from parameterized constructor 
//using Demo() ->allowed 
//inside constructor compiler create new object 
#include <iostream>

class Demo{
    public:
    int n1 = 10;
    
    Demo(){
        
        std::cout <<"no-arg constructor"<<std::endl;
    }
    Demo(int n1){
        Demo();
        std::cout <<"Parameterized Constructor"<<std::endl;
    }
    Demo(Demo& obj){
        std::cout <<"Copy Constructor" <<std::endl;
    }
    void getInfo(){
        std::cout << n1 << std::endl;
        std::cout <<this->n1<< std::endl;
    }
};
int main(){
    Demo obj1(10);

    return(0);
}
/*no-arg constructor
Parameterized Constructor*/