
//5th scenerio of copy constructor 
//array of struct , 
//array of object 
#include <iostream>

class Demo {
    public:
        Demo(){
            std::cout <<"no-arg-constructor"<<std::endl;
        }
        Demo(int n1){
            std::cout <<"In parameter"<<std::endl;
        }
        Demo(Demo &ref){
            std::cout <<"In copy "<<std::endl;
        }
};
int main(){

    Demo obj1;
    Demo obj2;
    Demo obj3;

    Demo arr[] = {obj1,obj2,obj3};

    /*
    Demo arr[0] = obj1;
    Demo arr[1] = obj2;
    Demo arr[2] = obj3;

    this is initialization ->then call goes to copy constructor 

    
    */
    return(0);
}
/*
output
no-arg-constructor
no-arg-constructor
no-arg-constructor
In copy
In copy
In copy
*/