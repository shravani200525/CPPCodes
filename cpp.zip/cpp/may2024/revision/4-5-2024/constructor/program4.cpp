/*
    why to use 
    3.copy constructor 
    ->to notify same copy of object is being created 
  
*/

#include<iostream>
class demo
{
    //instance variable
    int n1=10;
    int n2=20;
    public:
    //no argument constructoro
    demo()
    {
        std::cout<< "in no argument constructor" <<std::endl;
    }
    //copy constructor
    demo(demo& obj)
    {
        std::cout<< "in copy constructor" << std::endl;
    }
    //member function
    void fun()
    {
        std::cout<< n1 << std::endl;
        std::cout<< n2 << std::endl;
    }
};

//main function
int main()
{
    //object creating
    demo obj; //call no argument constructor
    demo obj1(obj);//call copy constructor
    obj1.fun();

}

//output:
//in no argument constructor
//in copy constructor
//10
//20