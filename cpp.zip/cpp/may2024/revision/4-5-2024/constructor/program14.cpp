//4th->copy constructor scenerio
//returning object from function 
#include <iostream>
class Demo{
    int n1 = 10;
    int n2 = 20;

    public:
        Demo(){
            std::cout <<"No Argument Constructor"<<std::endl;
        }
        Demo(int n1,int n2){
            this->n1 = n1;
            this->n2 = n2;
            std::cout <<"Parameterized Constructor"<<std::endl;
        }
        void getDetails(){
            std::cout << n1  << std::endl;
            std::cout<< n2 << std::endl;
        }
        Demo& getInfo(Demo& obj){
            obj.n1 = 700;
            obj.n2 = 800;
            return(obj);
        }
        Demo(Demo& ref){
            std::cout <<"Copy Constructor "<<std::endl;
        }
};
int main(){
    Demo obj1;
    obj1.getDetails();

    Demo obj2(100,200);
    obj2.getDetails();

    Demo obj3 = obj2.getInfo(obj1); //copy constructor 
    obj3.getDetails();
}
/*
output
No Argument Constructor
10
20
Parameterized Constructor
100
200
Copy Constructor
10
20
*/