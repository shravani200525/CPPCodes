//constructor
//how to write 3 types of constructor
//no argument,parameterized,copy constructor
//see how constructor are being called and their internal calls->this

#include<iostream>
class demo{
    //instance variable

    int n1=10;
    int n2=20;

    public:
    //no argument constructor
    demo()
    {
        std::cout<<"in no argument constructor"<<std::endl;
    }
    //parameterized constructor
    demo(int n1)
    {
        std::cout << "parameterized constructor"<< std::endl;
    }
    //copy constructor
    demo(demo& ref)
    {
        std::cout << "copy constructor"<<std::endl;
    }
    //member function
    void fun()
    {
        std::cout << n1 << std::endl;
        std::cout<<n2 << std::endl;
    }
};
//main function

int main()
{
    //object creation
    demo obj; //call no argument constructor ->internally demo obj(&obj)
    demo obj1(10); //call parameterized constructor -> internally demo obj1(&obj1,int)
    demo obj2(obj1); // call copy constructor -> internally demo obj2(&obj2,obj1)
    obj.fun(); // call member function
}

//output:
/*
in no argument constructor
parameterized constructor
copy constructor
10
20
*/