/*

    why to use 
    2.parameterized constructor (carrier)
    ->to change private variable of class from outside class,
    we use parameterized constructor , 
    take values from user  

*/

#include<iostream>
class demo
{
    //instance variable
    int n1;
    int n2;
    public:
    //parameterized constructor
    demo(int n1,int n2)
    {
        std::cout<< "in parameterized constructor"<<std::endl;
        this->n1=n1;
        this->n2=n2;
        std::cout<<n1 << std::endl;
        std::cout<< n2 << std::endl;
    }

    //memebr function
    void getinfo()
    {
        std:: cout<< n1 << std::endl;
        std::cout<< n2 << std::endl;
    }
};

//main function
int main()
{
    //accept value from user
    int n1;int n2;
    std:: cout<< "enter two nos"<< std::endl;
    std::cin>>n1>>n2;

    //object creation
    demo obj(n1,n2); //call parameterized constructor
    obj.getinfo(); //call member function

}

//output:
/*
enter two nos
12
14
in parameterized constructor
12
14
12
14
*/