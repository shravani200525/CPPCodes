//calling copy constructor from no-arg-constructor 
//using Demo(this); -> not allowed 
//it will not call copy constructor 
#include <iostream>

class Demo{
    public:
    int n1 = 10;
    
    Demo(){
        Demo(this);
        std::cout <<"no-arg constructor"<<std::endl;
    }
    Demo(int n1){
        std::cout <<"Parameterized Constructor"<<std::endl;
    }
    Demo(Demo& obj){
        std::cout <<"Copy Constructor" <<std::endl;
    }
    void getInfo(){
        std::cout << n1 << std::endl;
        std::cout <<this->n1<< std::endl;
    }
};
int main(){
 
    Demo obj1;

    return(0);
}
/*error: invalid conversion from ‘Demo*’ to ‘int’ [-fpermissive]
  Demo(this);
   */