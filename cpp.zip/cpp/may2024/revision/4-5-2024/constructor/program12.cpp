//2nd scenerio->copy constructor
//calling copy constructor from no-arg-constructor 
#include <iostream>
class Demo
{
    public:
        int n1 = 10;

        Demo()
        {
            Demo obj5(10);//parameterized constructor 
            Demo obj6(obj5);//copy constructor 
        }
        Demo(int n1)
        {
            std::cout <<"parameterized Constructor "<<std::endl;
        }
        Demo(Demo& ref)
        {
            std::cout << "Copy Constructor "<<std::endl;
        }
};
int main(){
    Demo obj1;

    return(0);
}
/*parameterized Constructor
Copy Constructor*/