//destructor in stack
//destructor in scope

#include<iostream>
class demo
{
    public:
    //constructor
    demo()
    {
        std::cout<<"in the no argument constructor"<<std::endl;
    }
    //destructor
    ~demo()
    {
        std::cout<<"in the destructor"<<std::endl;
    }
};
int main(){
{
    demo obj;
}
std::cout<< "end main"<<std::endl;
}
/*in the no argument constructor
in the destructor
end main*/