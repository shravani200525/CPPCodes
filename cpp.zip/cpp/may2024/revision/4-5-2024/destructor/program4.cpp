//Destructor in heap
//Destructor when object created with new on heap  
//destructor call by compiler when delete object on heap

#include<iostream>
class demo{
    public:
    //constructor
    demo()
    {
        std::cout<<"in constructor"<<std::endl;
    }
    
    ~demo()
    {
        std::cout<<"in destructor"<<std::endl;
    }
};
int main()
{
    demo obj1;
    demo *obj2 = new demo();
    delete(obj2);
    std::cout<<"end main"<<std::endl;
}
/*
output
in constructor
in constructor
in destructor
end main
in destructor
*/