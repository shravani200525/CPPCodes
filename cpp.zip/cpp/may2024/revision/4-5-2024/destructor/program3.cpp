//destructor in heap
//destructor when object created with new on heap

#include<iostream>
class demo
{
    public:
    //constructor
    demo()
    {
        std::cout<< "in the constructor"<<std::endl;
    }
    //destructor
    ~demo()
    {
        std::cout<< "In destructor"<<std::endl;
    }
};
int main()
{
    demo obj1;
    demo *obj2 = new demo();
    std::cout<< "end main"<<std::endl;
}
/*
output
in the constructor
in the constructor
end main
In destructor
*/