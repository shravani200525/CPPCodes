//destructor in stack
//destructor in main scope

#include<iostream>
class demo
{
    public:
    //no argument constructor
    demo()
    {
        std::cout<< "in the no argument constructor"<<std::endl;
    }
    //destructor
    ~demo()
    {
        std::cout<<"in the destructor"<<std::endl;
    }
};
//main function
int main()
{
    demo obj;
    std::cout<<"end main"<<std::endl;
}
/*
output
in the no argument constructor
end main
in the destructor
*/