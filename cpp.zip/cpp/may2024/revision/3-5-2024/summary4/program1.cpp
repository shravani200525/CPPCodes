//this pointer concept
//second object creation ->new, initialization with {} -> not allowed

#include<iostream>
class demo
{
    public:
        int n1=10;
        int n2=20;
    demo()
    {
        std::cout<< "in no argument constructor"<<std::endl;
        std::cout<< this << std::endl;
    }
    void fun()
    {
        std::cout<< this << std::endl;
        std::cout<< this->n1 << std::endl;
        std::cout<< this->n2 << std::endl;
    }
};
int main()
{
    demo *obj = new demo() {12,45};
    obj->fun();
}