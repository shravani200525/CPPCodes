#include<iostream>
class demo{
    public:
        int a=10;
        static int b;
        public:
            void fun()
            {
                std:: cout << "a =" <<a<< std::endl;
                std::cout << "b =" <<b << std ::endl;
            }
};
int demo::b=20;

int main()
{
    demo obj1,obj2;
    obj1.fun();
    obj2.fun();

    //instance variable change which is not reflect in obj2;
    obj1.a = 100;
    obj1.fun();
    obj2.fun();

    //static variable change which reflect in obj2;
    obj1.b=250;
    obj1.fun();
    obj2.fun();
}


//output:
//a =10
//b =20
//a =10
//b =20
//a =100
//b =20
//a =10
//b =20
//a =100
//b =250
//a =10
//b =250