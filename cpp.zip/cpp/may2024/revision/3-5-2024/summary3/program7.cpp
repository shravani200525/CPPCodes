//initialization public variable 3 ways
// 3rd way inside main() using ()
#include<iostream>
class demo{
    public:
        int a;
    void fun()
    {
        std:: cout << a << std::endl;
    }
};
int main()
{
    demo obj;
    obj.a= 80;
    obj.fun();
}
//output
//80