//initialization public variable 3 ways
// 1st way inside class
#include<iostream>
class demo{
    public:
        int a = 20;
    void fun()
    {
        std:: cout << a << std::endl;
    }
};
int main()
{
    demo obj;
    obj.fun();
}
//output
//20