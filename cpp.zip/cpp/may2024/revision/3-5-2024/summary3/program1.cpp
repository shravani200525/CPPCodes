//summary 3
//access specifier
//public,private,protected variable and function
#include<iostream>
class demo
{
    private:
        int age=10;
        void fun()
        {
            std:: cout<< age<< std::endl;
        }
    public:
        float tax = 2500.20;
        void getinfo()
        {
            std::cout<< tax << std::endl;
        }
    protected:
        char wing = 'A';
        void getdetail(){
            std::cout<< wing << std::endl;
        }
};
int main()
{
    demo obj;
    obj.fun();
    obj.getinfo();
    obj.getdetail();
}

//error ‘void demo::fun()’ is private within this context
//error ‘void demo::getdetail()’ is protected within this context