//initialization private variable in 3 ways
//1st way inside class
#include<iostream>
class demo
{
    private:
    int a=10;
    void fun()
    {
        std::cout<< a << std::endl;
    }
};
int main()
{
    demo obj;
    obj.fun();
}
//output:
//ld returned 1 exit status

