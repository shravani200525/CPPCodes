//initialization public variable 3 ways
// 2nd way inside main() using {}
#include<iostream>
class demo{
    public:
        int a;
    void fun()
    {
        std:: cout << a << std::endl;
    }
};
int main()
{
    demo obj{10};
    obj.fun();
}
//output
//10