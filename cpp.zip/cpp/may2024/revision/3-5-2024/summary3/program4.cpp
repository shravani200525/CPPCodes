//initialization private variable in 3 ways
//3rd way parameterized constructor

#include<iostream>
class demo{
    int n1=10;
    int n2=12;
    public:
        demo()
        {
            std::cout<< "in constructor"<<std::endl;
            std::cout << n1 << std ::endl;
            std:: cout << n2 << std::endl;
        }
        demo(int n1,int n2)
        {
            this ->n1=n1;
            this ->n2=n2;
            std::cout<< "in parameter constructor"<<std::endl;
            std::cout << n1 << std ::endl;
            std:: cout << n2 << std::endl;
        }
};
int main()
{
    demo obj1;
    demo obj2(25,89);

}
//output:
//in constructor
//10
//12
//in parameter constructor
//25
//89
