//initialization private variable in 3 ways
//2nd way setter & getter method

#include<iostream>
class Madiator
{
    int mno;
    std::string mname;
    public:
        void getter()
        {
            std::cout<< mno <<"," << mname << std::endl;
        }
        void setter(int sno,std::string sname)
        {
            this->mno = sno;
            this->mname = sname;
        }
};

int main()
{
    Madiator med;
    med.setter(10,"raj");
    med.getter();
}
//output:
//10,raj