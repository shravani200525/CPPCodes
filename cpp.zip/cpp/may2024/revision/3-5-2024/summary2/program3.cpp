//summary 2
//object creation 2 ways
//use delete to free object

#include<iostream>
class demo
{
    int age=10;
    std::string name="ajay";
    public:
    //constructor
    demo()
    {
        std::cout<< "in the class constructor" << std::endl;
    }
    void getinfo()
    {
        std::cout<< age << std::endl;
        std::cout<< name << std::endl;
    }
};

int main()
{
    //1st way of object creating
    demo obj1;
    obj1.getinfo();
    //2nd way of object creating
    demo *obj = new demo();
    obj->getinfo();
    //delete the object obj
    delete obj;
}
//output:
//in the class constructor
//10
//ajay
//in the class constructor
//10
//ajay