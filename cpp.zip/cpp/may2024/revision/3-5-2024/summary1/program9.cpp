//class variable
//instance variable
//public constructor allowed

#include<iostream>
class demo
{
    public:
    //constructor
    demo()
    {
        std::cout<<"in constructor"<<std::endl;
    }
};

int main()
{
    demo obj;
}