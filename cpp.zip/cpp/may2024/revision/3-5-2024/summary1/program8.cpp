//class variable
//instance variable
//private constructor not allowed

#include<iostream>
class demo
{
    private:
    //constructor
    demo()
    {
        std::cout<<"in constructor"<<std::endl;
    }
};

int main()
{
    demo obj;
    
}

//error  ‘demo::demo()’ is private within this context