//class variable
//static variable
//declaration inside class  allowed

#include<iostream>
class demo
{
    public:
    int a=10;
    static int b;

    public:
        void fun()
        {
            std::cout<< a << std::endl;
            std::cout<< b << std::endl;
        }
};

int main()
{
    demo obj;
    obj.fun();
}