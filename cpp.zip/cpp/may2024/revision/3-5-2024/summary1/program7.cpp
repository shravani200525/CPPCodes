//class variable
//instance variable
//instance variable intiliazation inside constructor

#include<iostream>
class demo
{
    public:
    //constructor
    demo()
    {
        int a=10;
        std::cout<<"a = "<<a <<std::endl;
    }
};

int main()
{
    demo obj;
    
}