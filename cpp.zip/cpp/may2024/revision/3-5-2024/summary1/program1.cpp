// class require semicolon

#include<iostream>
class demo{
    public:
        demo()
        {
            std::cout<< "in class constructor:"<<std::endl;
        }
};
int main()
{
    demo obj;
}