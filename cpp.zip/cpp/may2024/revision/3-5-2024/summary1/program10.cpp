//class variable
//instance variable
//class size & object size with sizeof operator

#include<iostream>
class demo
{
    public:
    int a=10;
    double b = 2.5;
    int *ptr;
    //constructor
    demo()
    {
        std::cout<<"in constructor"<<std::endl;
    }
    void fun()
    {
        std::cout<< a << std::endl;
        std::cout<< b << std::endl;

    }
};

int main()
{
    demo obj;
    obj.fun();
    std::cout<< sizeof(demo) << std::endl; //24
    std:: cout<< sizeof(obj) << std::endl; //24
}