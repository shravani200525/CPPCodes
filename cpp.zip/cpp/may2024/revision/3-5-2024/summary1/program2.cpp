//private function cannot call outside the class

#include<iostream>
class demo
{
    private:
    int a=10;
    private:
    void fun()
    {
        std::cout<<"a = "<<a <<std::endl;
    }
};
int main()
{
    demo obj;
    obj.fun();
}

//error= ‘void demo::fun()’ is private within this context