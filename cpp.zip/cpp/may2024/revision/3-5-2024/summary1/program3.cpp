//class variable
//static variable
//initialization inside class not allowed

#include<iostream>
class demo
{
    public:
    int a=10;
    static int b=20; //error  initialization of non-const static member ‘demo::b’

    public:
        void fun()
        {
            std::cout<< a << std::endl;
            std::cout<< b << std::endl;
        }
};

int main()
{
    demo obj;
    obj.fun();
}