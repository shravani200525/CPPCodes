//common iterator
//without using of auto error

//3rd cbegin -> cbegin means const which cannot change the value
//4th cend -> cend means const
#include<iostream>
#include<vector>
int main(){
//vector
std::vector<int> vobj = {10,20,30,40,50};

//Iterator
// std::vector<int>::iterator itr; //itr is internally pointer 

//error solution..
std::vector<int>::const_iterator itr;

for(itr=vobj.cbegin(); itr != vobj.cend(); itr++){
//itr const jalyamule apn itr chi value change nhi kru shakt 
    //*itr = 100; //error
    std::cout<<*itr<<std::endl;
}
}
/*
error: no match for ‘operator=’
output
10
20
30
40
50
*/