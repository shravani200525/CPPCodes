//rbegin and rend
//using auto

#include<iostream>
#include<vector>
int main(){
    //vector
    std::vector<int> vobj = {25,27,24,16,26,21};
    //iterator
    // std::vector<int>::iterator itr;
    for(auto itr=vobj.rbegin(); itr!= vobj.rend();itr++){
        std::cout<<*itr<<std::endl;
    }
}
/*
21
26
16
24
27
25
*/