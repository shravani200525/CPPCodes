//5th rbegin -> which means reverse
//6ht rend -> which means revers end
//without auto error
//so solution is...

#include<iostream>
#include<vector>
int main(){
    //vector
    std::vector<int> vobj ={10,20,30,40,50};
    //iterator
    // std::vector<int>::iterator 
    //solution of error

    std::vector<int>::reverse_iterator itr;

    for(itr=vobj.rbegin(); itr!=vobj.rend(); itr++){
        std::cout<<*itr<<std::endl;

    }
}
/*
50
40
30
20
10
*/