//cbegin and cend
//by using auto

#include<iostream>
#include<vector>

int main(){
    //vector
    std::vector<float> vobj= {3.5,8.2,78.2};
    //iterator
    //std::vector<float>::iterator itr;

    for(auto itr=vobj.cbegin(); itr !=vobj.cend();itr++){
        //*itr = 100;
        std::cout<<*itr<<std::endl;
    }
}
/*
3.5
8.2
78.2
*/