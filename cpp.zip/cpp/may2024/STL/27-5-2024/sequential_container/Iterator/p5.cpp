//using auto
//begin and end

#include<iostream>
#include<vector>
int main(){
    //vector
    std::vector<char> vobj ={'A','B','C'};
    //iterator
    // std::vector<char>::iterator itr;

    for(auto itr=vobj.begin(); itr!=vobj.end(); itr++){
        std::cout<<*itr<<std::endl;
    }
}
/*
A
B
C
*/