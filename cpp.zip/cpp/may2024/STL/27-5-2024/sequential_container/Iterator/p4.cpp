//7th crbegin ->const and reverse
//8th crend -> const and reverse
//without auto error

#include<iostream>
#include<vector>
int main(){
    //vector
    std::vector<int> vobj ={10,20,30,40,50};
    //iterator
    //without auto error
    // std::vector<int>::iterator itr;

    //solution of error
    std::vector<int>::const_reverse_iterator itr;
    for(itr = vobj.crbegin(); itr!=vobj.crend(); itr ++){
        // *itr = 100;
        std::cout<<*itr<<std::endl;
    }
}
/*
50
40
30
20
10
*/