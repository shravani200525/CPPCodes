//common iterator
//iterator che total 8fun ahet
//without using of auto
//1st begin
//2nd end
#include<iostream>
#include<vector>
int main(){
//vector
std::vector<int> vobj = {10,20,30,40,50};

//Iterator
std::vector<int>::iterator itr; //itr is internally pointer

std::cout<<sizeof(itr)<<std::endl; //8

for(itr=vobj.begin(); itr != vobj.end(); itr++){ //begin and end he ek iterator che function ahet
    std::cout<<*itr<<std::endl;
}
}
/*
10
20
30
40
50
*/