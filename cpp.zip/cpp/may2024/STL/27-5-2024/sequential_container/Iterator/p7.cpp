//crbegin and crend
//using auto

#include<iostream>
#include<vector>
int main(){
    //vector
    std::vector<std::string> vobj = {"shravani","jidnya"};
    //iterator
    //std::vector<std::string>::iterator itr;
    for(auto itr=vobj.crbegin(); itr!=vobj.crend();itr++){
        //*itr =  "anjali";
        std::cout<<*itr<<std::endl;
    }
}
/*
jidnya
shravani
*/