//use vector size() fun
#include<iostream>
#include<vector>
int main(){
    std::vector<char> vobj{'A','B','C','D','E'};

    std::cout<<vobj.size()<<std::endl; //size he ek vector chi method ahe
    //size ni vector chi size print 

    for(int i=0; i<vobj.size(); i++){
        std::cout<<vobj[i]<<std::endl;
    }
}
/*
5
A
B
C
D
E
*/