//vector member function chya at pn chalt

#include<iostream>
#include<vector>

class demo
{
    int a=10;
    int b=20;
    public:
        demo(){
            std::cout<<"constructor"<<std::endl;
        }
        void display(){
            std::cout<<a<<std::endl;
            std::cout<<b<<std::endl;
            // std::cout<<vobj<<std::endl;
        }
        void dis(){
            std::vector<int> vobj={100,200,300,400,500};
            vobj.push_back(600);

            std::vector<int>::iterator itr;

            for(itr=vobj.begin();itr!=vobj.end(); itr++)
            {
                std::cout<<*itr<<std::endl;
            }
            std::cout<<vobj.at(4)<<std::endl;
            std::cout<<"front:"<<vobj.front()<<std::endl;
        }
        
    
};
int main()
{
    std::vector<int> vobj;
    vobj.push_back(1000);

    std::vector<int>::iterator itr;

    for(itr=vobj.begin();itr!=vobj.end(); itr++)
    {
        std::cout<<*itr<<std::endl;
    }

    demo obj;
    obj.display();
    vobj.dis();
}