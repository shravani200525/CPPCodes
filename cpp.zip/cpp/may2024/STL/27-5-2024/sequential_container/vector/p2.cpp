//real time example
//using class
#include<iostream>
#include<vector>
class movie
{
    std::string Mname;
    float ratings;
    public:
        movie(std::string Mname,float ratings){
            this-> Mname = Mname;
            this-> ratings = ratings;
        }
        void display(){
            std::cout<< Mname <<":"<<ratings <<std::endl;
        }
};
int main()
{
    movie mobj1 ("shiddat",9.5);
    movie mobj2("yjhd",8.5);
    movie mobj3("salaar",6.9);
    std::vector<movie> vobj={mobj1,mobj2,mobj3}; //template madhi purn class dila ahe mhnun parameter madhi object pass kelet
    for(int i=0; i<vobj.size(); i++){
        vobj[i].display();
    }
}
/*
output
shiddat:9.5
yjhd:8.5
salaar:6.9
*/