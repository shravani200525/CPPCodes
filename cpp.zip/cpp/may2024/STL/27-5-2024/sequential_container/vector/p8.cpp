//vector data fun
#include<iostream>
#include<vector>
int main(){
    std::vector<char> vobj{'A','B','C','D','E'};

    std::cout<<vobj.data()<<std::endl; //data he ek vector chi method ahe
    //data ni purn data print zala

    for(int i=0; i<vobj.size(); i++){
        std::cout<<vobj[i]<<std::endl;
    }
}
/*
ABCDE
A
B
C
D
E
*/