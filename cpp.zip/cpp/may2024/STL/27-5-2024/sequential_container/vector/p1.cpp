//stl standard template libarary
//template has 3 parts container,interator,algorithm
//container devide into 4ways
//sequential container, container adapter,associative container, unordered associative container
//1st sequential container 
//1st vector class
//use push_back()
#include<iostream>
#include<vector>
int main(){
    std::vector <int>vobj; //ha vector os ni lihilela class ahe mhnun tyachya adhi std laval ahe karan to standard namespace chya at 
    //madhi ahe 
    vobj.push_back(100); //hi vector class chi ek method ahe
    vobj.push_back(200);
    vobj.push_back(300);
    vobj.push_back(400);
    vobj.push_back(500);

    for(int i=0; i<vobj.size();i++){ // size ha ek vector class cha member fun ahe
        std::cout<<vobj[i]<<std::endl;
    }
}
/*
100
200
300
400
500
*/