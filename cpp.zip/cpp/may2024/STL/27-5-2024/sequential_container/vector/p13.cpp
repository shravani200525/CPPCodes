#include<iostream>
#include<vector>

int main(){

    std::vector<int> vect={10,20,30,40,50};

    vect.push_back(100);

    std::cout<<"position"<<vect[0]<<std::endl;

    std::cout<<"at"<<vect.at(5)<<std::endl;

    std::cout<<"size"<<vect.size()<<std::endl;
    
    std::cout<<"capacity"<<vect.capacity()<<std::endl;

    std::cout<<"data"<<vect.data()<<std::endl;

    std::cout<<"front"<<vect.front()<<std::endl;

    std::cout<<"back"<<vect.back()<<std::endl;

    // vect.erase(2)<<std::endl;

    vect.clear();
    

    vect.pop_back();
}