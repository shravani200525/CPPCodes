//vector friend fun chya at madhi chalat

#include<iostream>
#include<vector>

class vectors
{
    int a=10;
    int b=20;
    public:
        vectors(){
            std::cout<<"constructor"<<std::endl;
        }
        ~vectors(){
            std::cout<<"destructor"<<std::endl;
        }
        friend void add(vectors &obj);
};
//friend function
void add(vectors &obj){
    std::cout<<obj.a + obj.b<<std::endl;

    //vector
    std::vector<int> vobj={101,102,103,104,105};

    vobj.push_back(106);
    std::cout<<"at="<<vobj.at(0)<<std::endl;

    //iterator
    std::vector<int>::iterator itr;
    for(itr=vobj.begin(); itr!= vobj.end(); itr++){
        std::cout<<*itr<<std::endl;
    }
} 
int main(){

    
    vectors obj;
    add(obj);
}
/*
constructor
30
at=101
101
102
103
104
105
106
destructor
*/