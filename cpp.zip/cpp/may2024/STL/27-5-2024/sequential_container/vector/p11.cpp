//clear vector fun
//it can remove all the elements
#include<iostream>
#include<vector>
int main(){
    std::vector<char> vobj;
    vobj.push_back('A');
    vobj.push_back('B');
    vobj.push_back('C');

    //befor clear
    std::cout<<"befor clear vector is:"<<std::endl;
    for(int i=0;i<vobj.size();i++){
        std::cout<<vobj[i]<<std::endl;
    }

    //after clear
    vobj.clear();
    vobj.push_back('D');
    vobj.push_back('E');
    
    std::cout<<"after clear vector is:"<<std::endl;
    for(int i=0;i<vobj.size(); i++){
        std::cout<<vobj[i]<<std::endl;
    }
}
/*
befor clear vector is:
A
B
C
after clear vector is:
D
E
*/