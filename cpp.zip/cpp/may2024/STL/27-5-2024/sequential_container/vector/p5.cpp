//vector back fun
#include<iostream>
#include<vector>
int main(){
    std::vector<char> vobj{'A','B','C','D','E'};

    std::cout<<vobj.back()<<std::endl; //back he ek vector chi method ahe
    //back ni fkt last value print zali

    for(int i=0; i<vobj.size(); i++){
        std::cout<<vobj[i]<<std::endl;
    }
}
/*
E
A
B
C
D
E
*/