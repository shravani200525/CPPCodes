//vector swap fun

#include<iostream>
#include<vector>
int main(){
    std::vector<int> vobj1(5,100); //five int with value of 100
    std::vector<int> vobj2(2,305); //2 int with value of 305
    
    vobj1.swap(vobj2);
    
    std::cout<<"vobj1 contains"<<std::endl;
    for(int i=0;i<vobj1.size();i++){
        std::cout<<" "<<vobj1[i]<<std::endl;
    }
    std::cout<<"vobj2 contains"<<std::endl;
    for(int i=0;i<vobj2.size();i++){
        std::cout<<" "<<vobj2[i]<<std::endl;
    }
}
/*
vobj1 contains
 305
 305
vobj2 contains
 100
 100
 100
 100
 100
*/

