// erasing from vector
#include <iostream>
#include <vector>

int main ()
{
  std::vector<int> obj;

  // set some values (from 1 to 10)
  for (int i=1; i<=10; i++) obj.push_back(i);

  // erase the 4th element
  obj.erase (obj.begin()+2); //it can erase the first 3 elements

  // erase the first 3 elements:
  obj.erase (obj.begin(),obj.begin()+3); //it can erase the first 4 elements

  std::cout << "myvector contains:";
  for (unsigned i=0; i<obj.size(); ++i)
    std::cout << ' ' << obj[i];
  std::cout << '\n';

  return 0;
}
/*
myvector contains: 5 6 7 8 9 10
*/