//vector front fun
#include<iostream>
#include<vector>
int main(){
    std::vector<char> vobj{'A','B','C','D','E'};

    std::cout<<vobj.front()<<std::endl; //front he ek vector chi method ahe
    //front ni fkt 1st value print zali

    for(int i=0; i<vobj.size(); i++){
        std::cout<<vobj[i]<<std::endl;
    }
}
/*
A
A
B
C
D
E
*/