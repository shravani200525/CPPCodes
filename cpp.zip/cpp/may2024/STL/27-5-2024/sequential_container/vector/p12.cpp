#include<iostream>
#include<vector>
int main(){
    std::vector<int> vec ={10};

    // vec.push_back(100); //add element in the last

    std::cout<<vec.size()<<std::endl; //print the size

    std::cout<<vec.capacity()<<std::endl; // kiti jaga ahe check krto

    vec.push_back(20);
    std::cout<<"size"<<vec.size()<<std::endl; //2
    std::cout<<"capacity"<<vec.capacity()<<std::endl; //2

    
    vec.push_back(30);
    std::cout<<"size"<<vec.size()<<std::endl; //3
    std::cout<<"capacity"<<vec.capacity()<<std::endl; //4
    

}