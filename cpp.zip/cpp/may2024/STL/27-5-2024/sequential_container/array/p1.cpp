/*
array
    ->array is fix sized sequencer
    ->hyat size aplyal dyavi lagte

    member function:-
    Capacity
        ->size ->return the array size
        ->max_size -> return maximum size of the array
        ->empty -> return the bool value it indicates the array is empty or not
*/

#include<iostream>
#include<array>

int main(){
    std::array<int,5> aobj ={10,20,30,40,50};

    std::array<int ,5>::iterator itr;

    for(itr=aobj.begin(); itr!=aobj.end(); itr++){
        std::cout<<*itr<<std::endl;
    }

    //size fun indicates the size of the array
    std::cout<<"size ="<<aobj.size()<<std::endl;

    //return the maximum no of the arry
    std::cout<<"maxmimum size="<<aobj.max_size()<<std::endl;

    //array is empty or not
    std::cout<<"array ="<<(aobj.empty()? "is empty" : "is not empty")<<std::endl;

    
}
/*
10
20
30
40
50
size =5
maxmimum size=5
array =is not empty
*/


