/*
array memeber function:-
    Modifiers
        ->swap -> exchange content
        ->fill -> sets val as the value for all the elements in the array object
*/
#include<iostream>
#include<array>

int main()
{
    std::array<int,5> first={10,20,30,40,50};
    std::array<int,5> second = {102,202,605,506,569};

    //fill
    first.fill(5); //hyani sagal 5 print zal 5vela 
    second.fill(10);
    //he run krnya sathi baki sagl comment kraych ahe comment nhi kel tri chalt

//befor swap
    
    //iterator
    std::array<int ,5>::iterator itr;

    std::cout<<"first array:"<<std::endl;
    for(itr=first.begin();itr!=first.end();itr++){
        std::cout<<*itr<<std::endl;
    }

    std::cout<<"second array:"<<std::endl;
    for(itr=second.begin();itr!=second.end();itr++){
        std::cout<<*itr<<std::endl;
    }

//after swap
    first.swap (second); //swapping done here
    
    std::cout<<"after swap first array:"<<std::endl;
    for(itr=first.begin();itr!=first.end();itr++){
        std::cout<<*itr<<std::endl;
    }

    std::cout<<"after swap second array:"<<std::endl;
    for(itr=second.begin();itr!=second.end();itr++){
        std::cout<<*itr<<std::endl;
    }
}
/*
first array:
10
20
30
40
50
second array:
102
202
605
506
569
after swap first array:
102
202
605
506
569
after swap second array:
10
20
30
40
50
*/