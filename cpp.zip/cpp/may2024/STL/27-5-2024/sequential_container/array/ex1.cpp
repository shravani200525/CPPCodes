//array member function chya at pn chalt

#include<iostream>
#include<array>

class demo
{
    int a=10;
    int b=20;
    public:
        demo(){
            std::cout<<"constructor"<<std::endl;
        }
        void display(){
            std::cout<<a<<std::endl;
            std::cout<<b<<std::endl;
        }
        void dis(){
            std::array<int,5> aobj={100,200,300,400,500};
            

            std::array<int,5>::iterator itr;

            for(itr=aobj.begin();itr!=aobj.end(); itr++)
            {
                std::cout<<*itr<<std::endl;
            }
            std::cout<<"at="<<aobj.at(4)<<std::endl;
            std::cout<<"front:"<<aobj.front()<<std::endl;
        }
        
    
};
int main()
{
    std::array<int,5> aobj={10,20,30,40,50};


    std::array<int,5>::iterator itr;

    for(itr=aobj.begin();itr!=aobj.end(); itr++)
    {
        std::cout<<*itr<<std::endl;
    }

    demo obj;
    obj.display();
    obj.dis();
}