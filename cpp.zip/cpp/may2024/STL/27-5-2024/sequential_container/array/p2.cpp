/*
array member function:-
    Element Access
        ->operator[] ->return the reference at an position of array
        ->at -> return the reference at an position of array
        ->front -> it will return the first element of the array
        ->back -> it will return the last element of the array
        ->data -> it will print the all element of the array
*/

#include<iostream>
#include<array>

int main(){

    std::array<char,5> aobj ={'a','b','c','d','e'};
    
    std::array<char ,5>::iterator itr;
    for(itr=aobj.begin(); itr!=aobj.end(); itr++){
        std::cout<<*itr<<std::endl;
        
    }

   // operator[]
    for(int i=0;i<aobj.size();i++){
        std::cout<<"operator = "<<aobj[i]<<std::endl;
        // std::cout<<"at = "<<aobj.at(i)<<std::endl; //it will print all the element
    }

    //at
    std::cout<<"at = "<<aobj.at(3)<<std::endl;

    //front
    std::cout<<"front = "<<aobj.front()<<std::endl;

    //back
    std::cout<<"back = "<<aobj.back()<<std::endl;

    //data
    std::cout<<"data = "<<aobj.data()<<std::endl;
}
/*
a
b
c
d
e
operator = a
operator = b
operator = c
operator = d
operator = e
at = d
front = a
back = e
data = abcde
*/