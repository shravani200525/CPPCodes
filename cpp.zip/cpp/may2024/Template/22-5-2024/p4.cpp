//member function into template

#include<iostream>
class olympics
{
    float distance;
    public:
    olympics(float distance){
        this->distance=distance;
    }
    template<class T>
    T& max(T& n1,T& n2){ //jr hith T& as nhi lihil tr to error deto mhnun main madhi pn n1 & n2 pass kely
        if(n1 > n2)
            return n1;
        else
            return n2;
    }
    

    friend bool operator>(olympics& obj1,olympics& obj2){ //bool vaparl ahe because condition check kraychi ahe
        return(obj1.distance > obj2.distance);
    }

    friend std::ostream& operator<<(std::ostream& out,olympics& obj){ //jr starting la std::ostream& nhi dila tr error yete
    
        out<<obj.distance;
        return(out);
    }
    

};
int main(){
    olympics niraj(10.85f);
    olympics deepak(2.45f);
    //float n1 = 10.21f;
    //float n2 = 20.12f;
    //std::cout<<niraj.max(n1,n2)<<std::endl;
    std::cout<<niraj.max(niraj,deepak)<<std::endl;
}

/*
output
20.12
10.85
*/