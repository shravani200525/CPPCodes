//class template
//Internal class

#include<iostream>
template<class T>
class Template{
    T n1;
    public:
        Template()
        {
            std::cout<<"in constructor"<<std::endl;
        }

};
int main()
{
    //Template obj; //jr as object create kela tr error yeter
    // error: class template argument deduction failed:


    Template<int> *obj1 = new Template<int>();
    Template<float> *obj2 = new Template<float>();
}
/*
in constructor
in constructor
*/