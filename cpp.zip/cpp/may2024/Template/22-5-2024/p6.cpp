//class template
//Internal class

#include<iostream>
template<class T>
class Template{
    T n1;
    public:
        Template()
        {
            std::cout<<"in constructor"<<std::endl;
        }
};
//internally compiler int and float sathi class lihito
template<>
    class Template <int>{
        int n1;
        public:
            Template(){
                std::cout<<"specific constructor for int"<<std::endl;
            }
};
//internally compiler int and float sathi class lihito
template<>
    class Template <float>{
        int n1;
        public:
            Template(){
                std::cout<<"specific constructor for float"<<std::endl;
            }
};
int main()
{


    Template<int> *obj1 = new Template<int>(); //hyachya sathi sperate class lihil ahe

    Template<float> *obj2 = new Template<float>(); //hyachya sathi jr nhi lihil tr to by default 1st class consider krto
    //ata float sathi seprate class lihila ahe 
}
/*
specific constructor for int
specific constructor for float
*/