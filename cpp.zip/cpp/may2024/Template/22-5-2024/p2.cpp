//member function into template

#include<iostream>
class Demo
{
    int data;
    public:
    Demo(int data){
        this->data=data;
    }
    int max(int n1,int n2){
        if(n1 > n2)
            return n1;
        else
            return n2;
    }
    Demo& max( Demo& obj1, Demo& obj2){ //object check karayla he parat fun lihav lagal mhnun he double fun lihin talnyasathi template 
    //use krnr
        if(obj1 > obj2)
            return (obj1);
        else
            return(obj2);
    }

    friend bool operator>(const Demo& obj1,const Demo& obj2){ //bool vaparl ahe because condition check kraychi ahe
        return(obj1.data > obj2.data);
    }

    friend std::ostream operator<<(std::ostream& out,Demo& obj){ //jr starting la std::ostream& nhi dila tr error yete
    // error: use of deleted function ‘std::basic_ostream<_CharT, _Traits>::basic_ostream(const std::basic_ostrea

        out<<obj.data;
        return(out);
    }
    

};
int main(){
    Demo obj1(100);
    Demo obj2(200);
    std::cout<<obj1.max(10,20)<<std::endl;
    std::cout<<obj1.max(obj1,obj2)<<std::endl;
}

/*
output
20
200
*/