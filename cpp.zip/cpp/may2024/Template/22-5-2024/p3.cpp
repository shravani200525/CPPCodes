//member function into template

#include<iostream>
class Demo
{
    int data;
    public:
    Demo(int data){
        this->data=data;
    }
    template<class T>
    T& max(T& n1,T& n2){ //jr hith T& as nhi lihil tr to error deto mhnun main madhi pn n1 & n2 pass kely
        if(n1 > n2)
            return n1;
        else
            return n2;
    }
    

    friend bool operator>(const Demo& obj1,const Demo& obj2){ //bool vaparl ahe because condition check kraychi ahe
        return(obj1.data > obj2.data);
    }

    friend std::ostream& operator<<(std::ostream& out,Demo& obj){ //jr starting la std::ostream& nhi dila tr error yete
    
        out<<obj.data;
        return(out);
    }
    

};
int main(){
    Demo obj1(100);
    Demo obj2(200);
    int n1 = 10;
    int n2 = 20;
    std::cout<<obj1.max(n1,n2)<<std::endl;
    std::cout<<obj1.max(obj1,obj2)<<std::endl;
}

/*
output
20
200
*/