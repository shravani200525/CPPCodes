//member function into template

#include<iostream>
class Demo
{
    public:
    template<class T>
    T mul(T n1,T n2){
        return(n1*n2);
    }

};
int main(){
    Demo obj;
    std::cout<<obj.mul(10,20)<<std::endl;
    // std::cout<<obj.mul(20.2f,12.2f)<<std::endl;
}
//hya code madhi class madhlya ek member function la template kel ahe
//tr to ata int and float doni la pn ghenar
/*
output
200
246.44
*/