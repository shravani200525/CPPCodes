//singly link list
#include<iostream>
template<typename T>
struct Node{
    T data;
    Node *next;
};
template<class T>
class singlylinklist{
    Node<T>* head = NULL;
    public:
        Node<T>* createlinklist(T data){
            Node<T>* newnode = (Node<T>*)malloc(sizeof(Node<T>));
            newnode -> data = data;
            newnode -> next = NULL;
            return(newnode);
        }
        void addlinklist(T data){
            Node<T> * newnode = createlinklist(data);

            if(head == NULL){
                head = newnode;
            }else{
                Node<T> *temp = head;
                while(temp->next!=NULL){
                    temp = temp ->next;
                }
                temp ->next = newnode;
            }
        }
        void printLinklist(){
           Node<T> *temp = head;
            while(temp!=NULL){
                //std::cout<<("[%d]->", temp->data)<<std::endl;
                //std::cout<<("[%c]->", temp->data)<<std::endl;
                std::cout<<("[%f]->", temp->data)<<std::endl;
                temp = temp -> next;
            } 
        }
};
int main()
{
    // singlylinklist<int> obj;
    // obj.addlinklist(10);
    // obj.addlinklist(20);
    // obj.addlinklist(30);

    // singlylinklist<char> obj;
    // obj.addlinklist('A');
    // obj.addlinklist('B');
    // obj.addlinklist('C');

    singlylinklist<float> obj;
    obj.addlinklist(10.12f);
    obj.addlinklist(20.14f);
    obj.addlinklist(30.24f);

    obj.printLinklist();
    obj.printLinklist1();

}
