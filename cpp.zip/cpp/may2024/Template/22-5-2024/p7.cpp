#include<iostream>
template<class T>
class Template{
    T n1;
    public:
        Template(T n1){
            this->n1=n1;
        }
        void getdata(){
            std::cout<< n1 << std::endl;
        }
};
int main(){
    Template<int> obj1(10);
    Template<float> obj2(50.12f);
    Template<char> obj3('A');

    obj1.getdata();
    obj2.getdata();
    obj3.getdata();
}
/*
10
50.12
A
*/