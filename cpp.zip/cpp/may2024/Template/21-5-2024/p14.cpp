#include<iostream>
//solution
#include"p15.h" //after this output is 20
template <typename T>
T max(T n1,T n2);

int main()
{
    std::cout<<max(10,20)<<std::endl;
}
//error: ld returned 1 exit status
