#include<iostream>
template <typename T>
T max(T n1,T n2);

template<>
int max<int>(int n1,int n2){
    return(n1 > n2) ? n1 : n2;
}
char max(char n1, char n2){
    return(n1 > n2) ? n1 : n2;
}
int main()
{
    std::cout<<max('a','b')<<std::endl;
    std::cout<<max<int>(10,20)<<std::endl;
    std::cout<<max<>(20,30)<<std::endl; //he as lihil tri chalt to data value varun data type olkhun gheto
}
/*
output
b
20
30
*/