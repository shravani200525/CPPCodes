#include<iostream>
template <typename T>
T max (T n1,T n2){
    if(n1 > n2)
        return n1;
    else
        return n2;
}
int main()
{
    std::cout<<max(10,10.2f)<<std::endl;
}
// error: no matching function for call to ‘max(int, float)’

//error ali karan 2 different type che value pass kelet ani template madhi T declare kely to 
//T int madhi jaun basto

