#include<iostream>
int max(int n1,int n2)
{
    return(n1>n2) ? n1:n2;
}
float max(float n1,float n2)
{
    return(n1>n2) ? n1:n2;
}
double max(double n1,double n2)
{
    return(n1>n2) ? n1:n2;
}
char max(char n1,char n2)
{
    return(n1>n2) ? n1:n2;
}
int main()
{
    std::cout<<max(10,20)<<std::endl; // calling max function and pass integer values

    std::cout<<max(10.5f,20.5f)<<std::endl; //calling max function and pass float values

    std::cout<<max(15.2,52.2)<<std::endl; //calling max functiion and pass double values
    
    std::cout<<max('A','B')<<std::endl; //calling max function and pass char values 

    //1st code madhla problem solve karnyasathi vegvegle function lihile ahet
    //he evdhe sagle fun lihivale lagtat mhanun template use krtat
}
/*
output
20
20.5
52.2
B
*/