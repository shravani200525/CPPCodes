//compiler swata pratyek data type sathi specific function
//te ata apn lihinar ahe

#include<iostream>
template <typename t> //declaration of template
t max(t n1,t n2); //declaration of template

template<> //he as lihitat karan identify krayla ki he ek template function ahe
char max<char>(char n1,char n2){ //internally he as function compiler lihito
// starting char is output parameter
//<char> he input parameter ahe

    return(n1 > n2) ? n1 : n2;
}

template<> //he as lihitat karan identify krayla ki he ek template function ahe
int max<int>(int n1,int n2){ //internally he as function compiler lihito

    return(n1 > n2) ? n1 : n2;
}
template<> //he as lihitat karan identify krayla ki he ek template function ahe
float max<float>(float n1,float n2){ //internally he as function compiler lihito

    return(n1 > n2) ? n1 : n2;
}

template<> //he as lihitat karan identify krayla ki he ek template function ahe
double max<double>(double n1,double n2){ //internally he as function compiler lihito

    return(n1 > n2) ? n1 : n2;
}
int main()
{
    std::cout<<max<char>('a','b')<<std::endl; //internally template <char> he asa call krto compiler
    std::cout<<max<int>(80,10)<<std::endl; //internally template <int> he asa call krto compiler
    std::cout<<max<float>(10.10f,15.10f)<<std::endl; //internally template <float> he asa call krto compiler
    std::cout<<max<double>(12.20,12.10)<<std::endl; //internally template <double> he asa call krto compiler

    //<char>... compiler he swata lihito identify krayla
}
/*
output
b
80
15.1
12.2
*/