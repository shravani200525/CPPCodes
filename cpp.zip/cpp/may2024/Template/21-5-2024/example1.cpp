#include<iostream>
template <typename T>
T mul(T n1){
    for(int i=0;i<5; i++)
    {
        std::cout<<n1<<std::endl;
    }
    return(n1);
}
int main()
{
    int n1;
    std::cout<<"enter no"<<std::endl;
    std::cin>>n1;
    mul(n1);
}