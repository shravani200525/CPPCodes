//solution of program12

#include<iostream>
template<typename T,typename U>
auto max(T n1,U n2){
    return(n1>n2) ? n1 : n2;
}
int main()
{
    std::cout<<max(10,50.12f)<<std::endl;
}
//ternary operator use kela ahe karan ifelse and ternary he same nhi ye
//output = 50.12