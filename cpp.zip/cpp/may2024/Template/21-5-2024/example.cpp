#include<iostream>
template <typename T>
T add(T n1,T n2){
    return(n1 + n2);
}
template <typename U>
U sub(U n1,U n2){
    return(n1 -n2);
}
int main()
{
    int choice;
    std::cout<<"enter choice"<<std::endl;
    std::cin>>choice;

    switch(choice)
    {
        case 1:
            std::cout<<add(10.10f,20.12f)<<std::endl;
            break;
        case 2:
            std::cout<<sub(20,10)<<std::endl;
            break;
        default:
            std::cout<<"wrong"<<std::endl;
    }
}