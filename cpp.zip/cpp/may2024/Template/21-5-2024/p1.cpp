#include<iostream>
int max(int n1,int n2)
{
    return(n1>n2) ? n1:n2;
}
int main()
{
    std::cout<<max(10,20)<<std::endl; // calling max function and pass integer values

    std::cout<<max(10.5f,20.5f)<<std::endl; //calling max function and pass float values
    //he int function aslya mule tyani hyala upgrade kel

    std::cout<<max(15.2,52.2)<<std::endl; //calling max functiion and pass double values
    //he int function aslya mule tyani hyala upgrade kel
    
    std::cout<<max('A','B')<<std::endl; //calling max function and pass char values 
    //char la ascii value print zali
}
/*
output
20
20
52
66
*/