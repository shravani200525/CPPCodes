#include<iostream>
template <typename T>
T max(T n1, T n2)
{
    return(n1 > n2) ? n1:n2;
}
//error: ld returned 1 exit status
//output 20