//function template

#include<iostream>
template<typename T> //hith typename chya jagi class pn lihu shakto

T max(T n1,T n2){
    return(n1 > n2) ? n1 : n2;
}

int main()
{
    std::cout<<max(10,20)<<std::endl; // calling max function and pass integer values

    std::cout<<max(10.5f,20.5f)<<std::endl; //calling max function and pass float values

    std::cout<<max(15.2,52.2)<<std::endl; //calling max functiion and pass double values
    
    std::cout<<max('A','B')<<std::endl; //calling max function and pass char values 
}

//program 2 madhi pratyek data type sathi vegla function lihila 
//tr te kami krnya sathi template lihila ahe
//typename T dila ahe mhnaje to kontya pn prakarcha data value asl tr to accept krto as it is
//T ha ek generic data type ahe

/*
output
20
20.5
52.2
B
*/