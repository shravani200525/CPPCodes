//program 10 ani 11 madhi je problem yet ahe te talnya sathi 
//auto keyword vaprtat (version 20)

#include<iostream>
template <typename T,typename U>
auto max (T n1,U n2){
    if(n1 > n2)
        return n1;
    else
        return n2;
}
int main()
{
    std::cout<<max(10,50.2f)<<std::endl;
}
//hith apn float and int value dili ahe mhnun template madhe T,U declare kel ahe
//auto max kela ahe mhnun error yetiye
// error: inconsistent deduction for auto return type: ‘int’ and then ‘float’
