#include<iostream>
template <typename T>
T max ( T n1,T n2){
    return(n1 > n2) ? n1 : n2;
}
int main()
{
    std::cout<<max<char>('a','b')<<std::endl; //internally template <char> he asa call krto compiler

    std::cout<<max<int>(80,10)<<std::endl; //internally template <int> he asa call krto compiler

    std::cout<<max<float>(10.10f,15.10f)<<std::endl; //internally template <float> he asa call krto compiler
    
    std::cout<<max<double>(12.20,12.10)<<std::endl; //internally template <double> he asa call krto compiler

    //<char>... compiler he swata lihito identify krayla
}
/*
output
b
80
15.1
12.2
*/