//multilevel inheritanc real time example

#include<iostream>
class grandfather
{
    public:
    void property()
    {
        std::cout<< "get home, plot"<<std::endl;
    }
};
class father:public grandfather
{
    public:
    void business()
    {
        std::cout<<"my milk business"<<std::endl;
    }
};
class son : public father
{
    public:
    void career()
    {
        std::cout<<"doctor"<<std::endl;
    }
};
int main()
{
    son obj;
    obj.property();
    obj.business();
    obj.career();
}