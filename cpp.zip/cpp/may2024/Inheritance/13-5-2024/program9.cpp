//single Inheritance

#include<iostream>
class parent
{
    int  n1 = 10;
    protected:
    int n2 = 20;
    public:
    int n3 = 30;
    
    void getinfor()
    {
        std:: cout << n1 << " " << n2 << " "<< n3 << std::endl;
    }
};
class child : public parent
{
    public:
    int n4 = 40;
    void getinfor()
    {
        std:: cout<< n4 << std::endl;
    }
};
int main()
{
    parent *obj = new child();
    obj->getinfor(); //call parent
    return(0);
}