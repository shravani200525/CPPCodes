//Inheritance types = public,private,protected

#include<iostream>
class parent
{
    private:
    int n1 =10;
    protected:
    int n2=20;
    public:
    int n3 = 30;
    parent()
    {
        std::cout<<"in parent constructor"<<std::endl;
    }
    void get()
    {
        std::cout<< n1 << std::endl;
        std::cout<< n2 << std::endl;
        std::cout<< n3 << std::endl;
    }
};
class child: private parent{

    public:
    child()
    {
       std::cout<<"in child constructor"<<std::endl;
    }
};
int main()
{
    child obj;
    std::cout<< obj.n1 << obj.n2 << obj.n3 << std::endl;
}
//error