//multiple inheritanc real time example

#include<iostream>
class fatherproperty
{
    public:
    void property()
    {
        std::cout<< "get home, plot"<<std::endl;
    }
};
class mothereproperty
{
    public:
    void mother()
    {
        std::cout<<"discipline"<<std::endl;
    }
};
class son : public fatherproperty,public mothereproperty
{
    public:
    void career()
    {
        std::cout<<"doctor"<<std::endl;
    }
};
int main()
{
    son obj;
    obj.property();
    obj.mother();
    obj.career();
}