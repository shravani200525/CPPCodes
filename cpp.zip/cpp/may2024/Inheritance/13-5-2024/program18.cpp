#include<iostream>
class parent
{
    int x = 10;
    public:
    friend std::ostream& operator<< (std::ostream& out,const parent& obj)
    {
        out<<"in parent"<<std::endl;
        out<<obj.x;
        return(out);
    }
};
class child:public parent
{

};
int main()
{
    std::cout<< sizeof(child)<<std::endl;
    child obj;
    std:: cout<< obj << std::endl;
    return(0);
}