//single inheritance
//real time example

#include<iostream>
class parent
{
    public:
    void property()
    {
        std:: cout<< "Home , Banglow , Car"<<std::endl;
    }
};
class child : public parent
{
    public:
    void career()
    {
        std::cout<<"doctor"<<std::endl;

    }
};
int main()
{
    child obj;
    obj.property();
    obj.career();
}