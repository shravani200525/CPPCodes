#include<iostream>
class parent1
{
    int x = 10;
    public:
    parent1()
    {
        std::cout<<"parent1 constructor"<<std::endl;
    }
    void getdata()
    {
        std::cout<< x << std::endl;
    }
};
class parent2
{
    int x = 10;
    public:
    parent2()
    {
        std::cout<<"parent2 constructor"<<std::endl;
    }
    void getdata()
    {
        std::cout<< x << std::endl;
    }
};
class child:public parent1,public parent2
{
    public:
    child()
    {
        std::cout<<"child constructor"<<std::endl;
    }
    /*
    void getdata()
    {
        std::cout<<"child.getdata()"<<std::endl;
        parent1::getdata();
        parent2::getdata();
    }
    */
};
int main()
{
    child obj;
    obj.getdata();
    return(0);
}