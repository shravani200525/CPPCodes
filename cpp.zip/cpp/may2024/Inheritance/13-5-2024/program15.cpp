//single inheritanc real time example

#include<iostream>
class father
{
    public:
    void property()
    {
        std::cout<< "get home, plot"<<std::endl;
    }
};
class son:public father
{
    public:
    void own()
    {
        std::cout<<"my own business"<<std::endl;
    }
};
int main()
{
    son obj;
    obj.property();
    obj.own();
}