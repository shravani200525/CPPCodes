//scope changing

#include<iostream>
class parent
{
    private:
    int n1 =10;
    protected:
    int n2=20;
    public:
    int n3 = 30;
    parent()
    {
        std::cout<<"in parent constructor"<<std::endl;
    }
    void get()
    {
        std::cout<< n1 << std::endl;
        std::cout<< n2 << std::endl;
        std::cout<< n3 << std::endl;
    }
};
class child: public parent{

    public:
    using parent::n2;
    private:
    using parent::void get;
    public:
    child()
    {
       std::cout<<"in child constructor"<<std::endl;
    }
};
int main()
{
    child obj;
}
//error