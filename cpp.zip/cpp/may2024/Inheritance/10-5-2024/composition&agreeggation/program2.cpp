//one real time example of composition using default constructor

#include<iostream>
class Manager
{
    std::string Mname = "karuna";
    int Mid = 10;
    float salary = 80000.00;
    public:
    //constructor
    Manager()
    {
        std::cout<< "Manager Constructor"<<std::endl;
    }
    ~Manager()
    {
        std::cout<<"Manager Destructor"<<std::endl;
    }
    void getdata()
    {
        std::cout<< Mname << std::endl;
        std::cout<< Mid << std::endl;
        std::cout << salary << std::endl;
    }
};
class Bank
{
    std:: string Bname = "SBI";
    std:: string Branch = "TilakRoad";
    int Bid = 11;
    int NoOfStaff = 30;
    Manager M1;
    public:
    Bank()
    {
        std::cout<<"Bank Constructor"<<std::endl;
    }
    ~Bank()
    {
        std::cout<<"Bank Destructor"<<std::endl;
    }
    void getdetails()
    {
        std::cout<< Bname << std::endl;
        std::cout << Branch << std::endl;
        std::cout<< Bid << std::endl;
        std::cout<< NoOfStaff << std::endl;
        M1.getdata();
    }
};
int main()
{
    Bank B1;
    B1.getdetails();
}
/*
output
Manager Constructor
Bank Constructor
SBI
TilakRoad
11
30
karuna
10
80000
Bank Destructor
Manager Destructor
*/