//program for inheritance
//change parent class variables in the child class by using parameterized constructor

#include<iostream>
class Parent
{
    int n1=10;

    protected:
    int n2=20;

    public:
    int n3=30;

    void getinfo()
    {
        std::cout<<n1 << " "<<n2 <<" "<<n3<< std::endl;
    }
};
class child :public Parent
{
    public:
    child(int n2,int n3)
    {

        this->n2=n2;
        this->n3=n3;
        std::cout<< "parameterized constructor"<<std::endl;
    }
    public:
    void get()
    {
        std::cout<<n2 <<" "<<n3<< std::endl;   
    }
};
int main()
{
    child ch1(500,900);
    ch1.getinfo();
    ch1.get();
}