//program for composition by using parameterized constructor
//getter and setter

#include<iostream>
class person
{
    std::string Pname;
    int pid;
    float ptax;
    public:
    person()
    {
        std::cout<<"in default constructor"<<std::endl;
    }
    person(std::string Pname,int pid,float ptax)
    {
        this->Pname=Pname;
        this->pid=pid;
        this->ptax=ptax;
        std::cout<<"Person constructor"<<std::endl;
    }
    ~person()
    {
        std::cout<<"Person Destructor"<<std::endl;
    }
    void getinfo()
    {
        std::cout<< Pname << std::endl;
        std::cout<< pid << std::endl;
        std::cout << ptax<< std::endl;
    }
    std::string getname()
    {
        return(Pname);
    }
    int getid()
    {
        return(pid);
    }
    float gettax()
    {
        return(ptax);
    }
    void setter(std::string Pname,int pid,float ptax)
    {
        this->Pname=Pname;
        this->pid=pid;
        this->ptax=ptax;
    }
};
class Building
{
    std::string Bname;
    int Bid;
    float Btax;
    person p1;
    public:
    Building()
    {
        std::cout<<"Building constructor"<<std::endl;
    }
    Building(std::string Bname,int Bid,float Btax, std::string Pname,int pid, float ptax)
    {
        this->Bname=Bname;
        this->Bid=Bid;
        this->Btax=Btax;
        p1.setter(Pname,pid,ptax);
        std::cout<<"Building Parameterized constructor"<<std::endl;
    }
    ~Building()
    {
        std::cout<< "Building Destructor"<<std::endl;
    }
    void getdata()
    {
        std::cout<<Bname<<std::endl;
        std::cout << Bid<< std::endl;
        std::cout<< Btax<<std::endl;
        p1.getname();
        p1.getid();
        p1.gettax();
        p1.getinfo();
    }
};
int main(){
    Building obj("lake vista",10,75000.00,"pankaj",602,12000.00);
    obj.getdata();
}
/*
output
in default constructor
Building Parameterized constructor
lake vista
10
75000
pankaj
602
12000
Building Destructor
Person Destructor
*/