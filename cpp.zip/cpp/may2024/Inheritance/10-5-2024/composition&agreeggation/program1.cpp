//program for Composition using default constructor

#include<iostream>
class Doctor
{
    std::string Dname ="Dr.ganesh";
    int Did = 10;
    public:
    Doctor()
    {
        std::cout<< "Doctor Constructor"<< std::endl;
    }
    ~Doctor()
    {
        std::cout<< "Doctor Destructor"<<std::endl;
    }
    void getdata()
    {
        std::cout<< Dname << std::endl;
        std::cout<< Did << std::endl;
    }
};
class Hospital
{
    std::string Hname= "lalvani";
    int Hid = 11;
    Doctor obj; //instance variable of hospital class
    public:
    Hospital()
    {
        std::cout << "Hospital Constructor"<<std::endl;
    }
    ~Hospital()
    {
        std::cout<<"Hospital Destructor"<<std::endl;
    }
    void getdetails()
    {
        std::cout<< Hname<< std::endl;
        std::cout<< Hid << std::endl;
        obj.getdata();
    }
};
int main()
{
    Hospital H1;
    H1.getdetails();
}
/*
output
Doctor Constructor
Hospital Constructor
lalvani
11
Dr.ganesh
10
Hospital Destructor
Doctor Destructor
*/