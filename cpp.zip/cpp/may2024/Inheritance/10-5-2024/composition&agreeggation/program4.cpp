//program for inheritance

#include<iostream>
class Parent
{
    int n1=10;

    protected:
    int n2=20;

    public:
    int n3=30;

    void getinfo()
    {
        std::cout<<n1 << " "<<n2 <<" "<<n3<< std::endl;
    }
};
class child :public Parent
{
    public:
    void getdata()
    {
        std:: cout<<n2 << " "<< n3<< std::endl;
    }
};
int main()
{
    child ch1;
    ch1.getinfo();//10 20 30
    ch1.getdata();//20 30
}