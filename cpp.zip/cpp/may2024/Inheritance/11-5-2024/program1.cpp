//parent and child- constructor sequence

#include<iostream>
class parent{

    public:
    parent()
    {
        std::cout<<"in parent constructor"<<std::endl;
    }
    ~parent()
    {
        std::cout<<"in parent destructor"<<std::endl;
    }
};
class child: public parent
{
    public:
    child()
    {
        //by default parent constructor call
        //parent();
        std::cout<<"in child constructor"<<std::endl;
    }
    ~child()
    {
        std::cout<<"in child destructor"<<std::endl;
    }
};
int main()
{
    child obj;
}