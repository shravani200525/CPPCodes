//parameterized constructor
#include<iostream>
class parent
{
    int a=10;
    int b = 20;
    int c= 30;
    public:
    parent()
    {
        std::cout<<"constructor = this" << this << std::endl;
    }    
    parent(int a,int b,int c)
    {
        this->a=a;
        this->b=b;
        this->c=c;
        std::cout<<"parent parameterized this =" << this<<std::endl;
    }
    ~parent()
    {
        std::cout<<"parent destructor"<<std::endl;
    }
    void get()
    {
        std::cout<< a<<" "<< b <<" "<< c<<std::endl;
    }
};

class child : public parent
{
    int e=50;
    int d = 40;
    public:
    child(int a,int b,int c,int d,int e): parent(a,b,c)
    {
        std::cout<<"child parameterized this =" << this <<std::endl;
    }
    ~child()
    {
        std::cout<<"child destructor"<<std::endl;
    }
    void getdata()
    {
        std::cout<< e <<" "<< d <<std::endl;
    }
};
int main()
{
    child obj(100,200,300,400,500);
    obj.get();
    return(0);
}