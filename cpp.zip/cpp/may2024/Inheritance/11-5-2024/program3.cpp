#include<iostream>
class parent
{
    public:
    parent()
    {
        std::cout<<"in parent constructor"<<std::endl;
    }
    ~parent()
    {
        std::cout<<"in parent destructor"<<std::endl;
    }
    friend void* operator new(size_t size)
    {
        std::cout<< "new"<<std::endl;
        void* ptr= malloc(size);
        return(ptr);
    }
    void operator delete (void* ptr)
    {
        std::cout<<"delete"<<std::endl;
        free(ptr);
    }
};
class child : public parent
{
    public:
    child()
    {
        std::cout<<"in child constructor"<<std::endl;
    }
    ~child()
    {
        std::cout<<"in child destructor"<<std::endl;
    }
    
};
int main()
{
    child *obj = new child();
    delete obj;
    return(0);
}