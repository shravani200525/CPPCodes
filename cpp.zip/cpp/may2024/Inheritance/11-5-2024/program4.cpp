#include<iostream>
class parent{

    int n1=10;
    int n2=20;
    int n3=30;
    public:
    parent()
    {
        std::cout<<"parent constructor"<<std::endl;
    }
    ~parent()
    {
        std::cout<<"parent destructor"<<std::endl;
    }
    void get()
    {
        std::cout<< n1 << " "<< n2 <<" " << n3 <<std::endl;
    }
};
class child: public parent{

    int n4=60;
    int n5=50;
    public:
    child()
    {
        std::cout<<"child constructor"<<std::endl;
    }
    ~child()
    {
        std::cout<<"child destructor"<<std::endl;
    }
    void getdata()
    {
        std::cout<< n4 << " "<< n5 <<std::endl;
    }
};
int main()
{
    parent obj;
    child obj1;
    obj.get();
    obj1.getdata();
    std::cout<<sizeof (obj)<<std::endl;
    std::cout<<sizeof(obj1)<<std::endl;
}