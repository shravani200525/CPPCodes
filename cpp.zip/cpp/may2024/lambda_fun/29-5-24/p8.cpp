//generic lambda

#include<iostream>
int main(){

    std::string cName="cpp";
    std::string cSession="third";
    int value = 100;
    std::cout<<"out"<<value<<std::endl;
    auto mul = [&] (auto n1,auto n2)mutable->auto{
        value++;
        std::cout<<cName<<std::endl;
        std::cout<<cSession<<std::endl;
        std::cout<<value<<std::endl; //101 print zal because of [&] this
        return(n1*n2);
    
    };
    std::cout<<mul(10,20)<<std::endl;    
    std::cout<<value<<std::endl; //101 print zal because of [&] this
}
/*
out100
cpp
third
101
200
101
*/