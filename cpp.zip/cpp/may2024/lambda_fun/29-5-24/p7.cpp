#include<iostream>
int main(){

    std::string cName="cpp";
    std::string cSession="third";
    int value = 100;
    std::cout<<"out"<<value<<std::endl;
    auto mul = [&] (int n1,int n2)mutable->int{
        value++;
        std::cout<<cName<<std::endl;
        std::cout<<cSession<<std::endl;
        std::cout<<value<<std::endl; //101 print zal because of [&] this
        return(n1*n2);
    
    };
    std::cout<<mul(10,20)<<std::endl;    
    std::cout<<value<<std::endl; //101 print zal because of [&] this
}
/*
output
out100
cpp
third
101
200
101
*/