//anymyous function -> call can possible only one time
//one time use

#include<iostream>
int main(){
    [] (int n1,int n2) {  //name nhi dil starting la

        std::cout<<n1 *n2<<std::endl; //200

    } (10,20); //jith sampal tithch call kela
     
    return(0);
}