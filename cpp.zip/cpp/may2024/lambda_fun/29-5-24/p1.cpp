/*
    Lambda FUnction
    ->similar to inline fun
    ->is develop in c++11 version
    ->it is generic develop in c++14
    ->not push on stack frame
    -> it is class and object because it does not have semicolon
    ->pass object to the fun
    ->use one time object
    ->it also called as anenymous ->it means it does not have name

    syntax
    ->[capture](parameter)->return data type{
        body;
    };
*/

#include<iostream>

int main(){
    auto mul = [] (int n1,int n2){
        std::cout<<n1 * n2<<std::endl;
    };
    mul(10,20); //operator overloading internally()

    // mul(10); error no match
}