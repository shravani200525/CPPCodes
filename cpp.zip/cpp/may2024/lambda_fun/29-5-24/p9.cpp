#include<iostream>
#include<functional>
int main(){

    std::function<int(int,int)> mul =[&] (int n1,int n2);
    
    //internal call of this line
    std::function<int>
    {
        int n4;
        int n5;
        function(int n4,int n5){
            this->n4=n4;
            this->n5=n5;
        }
        int operator()(int n4,int n5){
            return(n4*n5);
        }
    };
    
}
//error