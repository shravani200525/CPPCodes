/*
    lambda fun
    -> 5things given
    -> code is self explainatory
*/

#include<iostream>
int main(){
    auto mul = [] (int n1,int n2) -> int{
        return(n1*n2);
    };
    std::cout<<mul(10,20)<<std::endl;
    return(0);
}