#include<iostream>
int main(){
    std::string cName="cpp";
    std::string cSession="third";

    auto mul=[](int n1,int n2)->int{
        std::cout<<cName<<std::endl;
        std::cout<<cSession<<std::endl;

        return(n1*n2);
    };
}

/*
error
error: ‘cName’ is not captured
error: ‘cSession’ is not captured
*/