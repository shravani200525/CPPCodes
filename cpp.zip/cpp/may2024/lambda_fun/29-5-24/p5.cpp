#include<iostream>
int main(){

    std::string cName="cpp";
    std::string cSession="third";
    int value =100;
    std::cout<<"out"<<value<<std::endl;
    auto mul =[] (int n1,int n2)->int{
        value++;
        std::cout<<value<<std::endl;
        std::cout<<cName<<std::endl;
        std::cout<<cSession<<std::endl;
        return(n1*n2);
    };
}