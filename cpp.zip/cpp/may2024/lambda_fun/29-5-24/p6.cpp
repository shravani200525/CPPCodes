#include<iostream>
int main(){

    std::string cName="cpp";
    std::string cSession="third";
    int value = 100;
    std::cout<<"out"<<value<<std::endl;
    auto mul = [=] (int n1,int n2)mutable->int{
        value++;
        std::cout<<cName<<std::endl;   //print nhi zal change zalel tyachya sathi [&] he use karaych
        std::cout<<cSession<<std::endl;  //print nhi zal change zalel tyachya sathi [&] he use karaych
        std::cout<<value<<std::endl; //print nhi zal change zalel tyachya sathi [&] he use karaych
        return(n1*n2);
    };
}