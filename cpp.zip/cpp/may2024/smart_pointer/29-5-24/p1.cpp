/*
    Smart Pointer
    -> unique_ptr -><memory> header file include karaychi
    -> share_ptr -> obj share kartat ->count return krto
    ->veak_ptr -> ha jast use hot nahi

*/
//Unique_ptr

#include<iostream>
#include<memory>

class demo{
    int a,b;
    public:
    demo(int a,int b){
        this->a=a;
        this->b=b;
    }
    void add(){
        a+b;
    }
};
int main(){
    std::unique_ptr <demo>  *ptr = (new demo(10,20));
    std::cout<<ptr->add()<<std::endl;
}