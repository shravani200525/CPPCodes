#include<iostream>
class parent
{
    public:
    parent()
    {
        std::cout<<"in parent"<<std::endl;
    }
    virtual parent* marry(void)
    {
        std::cout<<"Katrina"<<std::endl;
        std::cout<<this<<std::endl;
        return(this);
    }
};
class child:public parent
{
    public:
    child()
    {
        std::cout<<"in child"<<std::endl;
    }
    child* marry(void)
    {
        std::cout<<"vicky"<<std::endl;
        std::cout<<this<<std::endl;
        return(this);
    }
};
int main()
{
    parent *obj = new child();
    parent* ptr; 

    //hyala error yet nahi because hyat return type "covariant" ahe
    //mhanje doniche address same ahet

    ptr = obj->marry();
    std::cout<<"in main"<<std::endl;
}