#include<iostream>
class parent
{
    public:
    void marry(int a)
    {
        std::cout<<"aliya bhatt"<<std::endl;
    }
};
class child : public parent
{
    public:
    void marry(void)
    {
        std::cout<<"ranbir kapoor"<<std::endl;
    }
};
int main()
{
    parent *obj = new child();

    //pareameter change kele tr override hot nhi 
     
    obj->marry(10);
}