#include<iostream>
class parent
{
    public:
    void marry(void)
    {
        std::cout<<"kat"<<std::endl;
    }
};
class child: public parent
{
    public:
    void marry(void)override{
        std::cout<<"vicky"<<std::endl;
    }
};
int main()
{
    parent *obj = new child();
    obj->marry();
}