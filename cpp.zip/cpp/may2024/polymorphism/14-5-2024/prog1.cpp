// Overriding :- 
	// Mhnje parent che function ani child che function same astil tr
	// child che function parent chya function vr override hotat ani child chya function la call jato

#include<iostream>
class parent{
    public:
    void marry(void)
    {
        std::cout<<"kiara"<<std::endl;
    }
    void career(void)
    {
        std::cout<<"Actress"<<std::endl;
    }
};

class child: public parent
{
    public:
    void marry(void)
    {
        std::cout<<"sid"<<std::endl;
    }
    void career(void)
    {
        std::cout<<"Actor"<<std::endl;
    }
};
int main()
{
    parent *obj = new child();

    //virtual keyword is not use then call the parent class
    //then overriding is not possible
    obj->marry();
    obj->career();
}