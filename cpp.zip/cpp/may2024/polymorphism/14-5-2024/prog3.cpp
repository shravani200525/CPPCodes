#include<iostream>
class parent{
    public:
    void marry(void)
    {
        std::cout<<"aliya bhatta"<<std::endl;
    }
};
class child : public parent
{
    public:
    virtual void marry(void)
    {
        std::cout<<"ranbir kapoor"<<std::endl;
    }
};

int main()
{
    parent *obj = new child();
    //jr child class la virtual kel tr override hot nhi
    //parent class lach call jato
    obj->marry();
}