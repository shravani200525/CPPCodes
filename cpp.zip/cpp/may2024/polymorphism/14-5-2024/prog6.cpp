#include<iostream>
class parent
{
    public:
    void marry(void) final //final use kel ki parent class inherite nhi karta yet
    //he ek prakare fix sarakh ahe
    {
        std::cout<<"kat"<<std::endl;
    }
};
class child : public parent{
    public:
    void marry(void)
    {
        std::cout<<"vic"<<std::endl;
    }
};
int main()
{
    int final = 10;
    parent *obj = new child();
    obj->marry();

    return(0);
}