#include<iostream>
class parent
{
    public:
    virtual float marry()
    {
        std::cout<<"ankita"<<std::endl;
        return(1.4f);
    }
};
class child : public parent
{
    public:
    int marry(void)
    {
        std::cout<<"vicky"<<std::endl;
        return(1);
    }
};
int main()
{
    parent *obj = new child();

    //if return type is different then it cannot be overriding
    //and it call the parent function
    obj->marry();

    //error: conflicting return type specified for ‘virtual int child::marry()
}