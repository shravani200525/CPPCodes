//this is example of static / early / compile time binding of function

#include<iostream>
void add(int a,int b)
{
    std::cout<< a + b <<std::endl;
}
void sub(int a , int b)
{
    std::cout<< a - b<< std::endl;
}
int main(){

    std::cout<<"1.add"<<std::endl;
    std::cout<<"2.sub"<<std::endl;

    int choice;
    std::cout<<"enter choice"<<std::endl;
    std::cin>> choice;

    switch(choice)
    {
        case 1:
            add(10,20);
            break;
        case 2:
            sub(20,10);
            break;
        default:
            std::cout<<"wrong"<<std::endl;
            break;
    }
    return(0);
}
