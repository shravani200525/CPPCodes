// This is how vptr works
// vptr is a array of pointer to function(virtual functions)

#include<iostream>

void add(int a,int b)
{
    std::cout<< a + b <<std::endl;
}
void sub(int a, int b)
{
    std::cout<< a - b<<std::endl;
}
int main(void)
{
    void (*fptr[2]) (int,int) = {add,sub};

    for(int i=0;i<2;i++)
    {
        fptr[i](10,20);
    }
    return(0);
}