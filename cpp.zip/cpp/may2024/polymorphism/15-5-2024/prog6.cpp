//Abstract Class

#include<iostream>
class parent
{
    virtual void marry() = 0;  //body compulsory lihavi lagte nhi tr object create hot nhi
    virtual void career() = 0;
};
class child : public parent
{

};
int main()
{
    child obj; //same error karan child madhi pn body nhi lihili
    //error: cannot declare variable ‘obj’ to be of abstract type ‘child’
    return(0);

}