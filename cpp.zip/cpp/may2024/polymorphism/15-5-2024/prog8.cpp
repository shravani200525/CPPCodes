//why use concept of adapter

#include<iostream>
class parent
{
    virtual void marry() = 0; // he virtual function ahe
    virtual void career() = 0;
};
class child: public parent
{
    public:
    void marry(void)
    {
        std::cout<<"kriti"<<std::endl;
    }
};
class child1 : public parent
{
    public:
    void career()
    {
        std::cout<<"acteress"<<std::endl;
    }
};
int main()
{
    child obj; //tari pan error yeti karan  child la career chi body nhi milate
    obj.marry();
    obj.career();

    //error: cannot declare variable ‘obj’ to be of abstract type ‘child’
    return(0);
}