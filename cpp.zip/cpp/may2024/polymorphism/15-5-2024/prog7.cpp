//pure virtual function

#include<iostream>
class parent
{
    virtual void marry() = 0; // this is a pure virtual function
    virtual void career() = 0;
};
class child:public parent
{
    public:
        void marry(void)
        {
            std::cout<<"kriti"<< std::endl;
        }
        void career(void)
        {
            std::cout<<"acteress"<<std::endl;
        }
};
int main()
{
    child obj;
    obj.marry();
    obj.career();
    return(0);
}