//pure virtual base class

#include<iostream>

class base
{
    public:
        void getinfo()
        {
            std::cout<<"in base"<<std::endl;
        }
};
class child : public base
{

};
class child1 : public base
{

};
class child2 : public child , public child1
{

};
int main()
{
    child2 obj;
    obj.getinfo(); //compiler la kalat nhi konty class madhun gheu
    // error: request for member ‘getinfo’ is ambiguous
    //this is called as diamond problem
    return(0);
}