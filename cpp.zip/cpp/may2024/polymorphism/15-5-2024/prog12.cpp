//pure virtual base class

#include<iostream>
class base
{
    public:
        base()
        {
            std::cout<<"in base"<<std::endl;
        }
        void getinfo()
        {
            std::cout<<"in getinfo"<<std::endl;
        }
};
class child : virtual public base{
    public:
        child()
        {
            std::cout<<"in child"<<std::endl;
        }
};
class child1 :virtual public base
{
    public:
        child1()
        {
            std::cout<<"in child1"<<std::endl;
        }
};
class child2 : public child,public child1{
    public:
        child2()
        {
            std::cout<<"in child2"<<std::endl;
        }
};

int main()
{
    child2 obj;//double constructor construction solved
    obj.getinfo();//diamond problem solved //compiler direct base madhun virtual use kelyavr
    return(0);
}