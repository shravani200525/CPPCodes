//that's why use of concept adapter

#include<iostream>
class parent
{
    virtual void marry() = 0; //he virtual function ahe
    virtual void career() = 0;
};
class adapter
{
    public:
    void marry()
    {
        //Dumy body
    }
    void career()
    {
        //Dumy body
    }
};

class child:public adapter
{
    public:
        void marry(void)
        {
            std::cout<<"kriti"<<std::endl;
        }
};
class child1 :public adapter
{
    public:
        void career()
        {
            std::cout<<"acteress"<<std::endl;
        }
};
int main()
{
    child obj;
    obj.marry();

    obj.career(); //ehte ky yet nhi pn error pn yet nhi 

    child1 obj1;
    obj1.career();

    obj1.marry(); //ethe ky yet nhi pn error pn yet nhi



    return(0);
}