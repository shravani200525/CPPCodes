
// Pure virtual base class

#include<iostream>

class base {
public:
	base()
	{
		std::cout << "In base" << std::endl;
	}
};

class child: public base {
public:
	child() {
		std::cout << "In child" << std::endl;
	}

};

class child1 : public base {
public:
	child1() {
		std::cout << "In child1" << std::endl;
	}

};


class child2 : public child,public child1 {
public:
	child2() {
		std::cout << "In child2" << std::endl;
	}

};

int main(void)
{
	child2 obj; // Base cha constructor donda call hoto ha problem ahe 
	// to problem virtual base class ne solve hoto
	// This is called as double constructor construction  problem
	return(0);
}

