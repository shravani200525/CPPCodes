//you can't use static and virtual at a time

#include<iostream>
class parent
{
    public:
    parent()
    {
        std::cout<<"in parent"<<std::endl;
    }
    virtual static void getinfo(void) //error: member ‘getinfo’ cannot be declared both ‘virtual’ and ‘static’
    {
        std::cout<<"in getinfo of parent"<<std::endl;
    }
};
class child:public parent{

    public:
    child()
    {
        std::cout<<"in child"<<std::endl;
    }
    static void getinfo(void)
    {
        std::cout<<"getinfo of child"<<std ::endl;
    }
};
int main()
{
    child obj;
    obj.getinfo();
    return(0);
}