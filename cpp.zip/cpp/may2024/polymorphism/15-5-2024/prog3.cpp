//this is example of dynamic / late/ run time binding of function

#include<iostream>
void add(int a,int b)
{
    std::cout<< a + b << std::endl;
}
void sub (int a, int b)
{
    std::cout<< a - b <<std::endl;
}
int main()
{
    void(*fptr)(int,int) = NULL;

    std::cout<<"1.add"<<std::endl;
    std::cout<<"2.sub"<<std::endl;

    int choice;
    std::cout<<"enter a choice"<<std::endl;
    std::cin>> choice;

    switch(choice)
    {
        case 1:
                fptr = add;
                break;
        case 2:
                fptr = sub;
                break;
        default:
                std::cout<<"wrong"<<std::endl;
                break;
    }
    fptr(10,10); //varcha switch depend ahe konala call jael
    return(0);
}