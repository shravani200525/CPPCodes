//File Handling
//write function 
//use ofstream class means output

#include<iostream>
#include<fstream> //this header file use in file handling
//1st way constructor
//by using constructor

int main(){
    std::ofstream outputobj ("friends.txt");  //hyani ek txt file create zali
    //parameter constructor use kela ahe jo internally asto
    //use std because ofstream is a standard class

    outputobj<<"Shravani\n";
    outputobj<<"Jidnyasa\n"; //data write kela ahe
    outputobj<<"Anjali\n"; 
    outputobj<<"Prasad\n";
    outputobj<<"Paras\n";
    outputobj<<"pratik\n";

    outputobj.close();
}