//File Handling
//write function 
//use ofstream class means output

#include<iostream>
#include<fstream> //this header file use in file handling
//2nd way method
//by using method

int main()
{
    std::ofstream outputobj;
    outputobj.open("language.txt"); //function use kela ahe

    
    outputobj<<"C\n";
    outputobj<<"DS\n";
    outputobj<<"CPP\n";
    outputobj<<"JAVA\n";
    outputobj<<"Python\n";
    outputobj<<"NodeJs\n";

    outputobj.close();
}