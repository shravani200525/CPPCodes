#include<iostream>
#include<fstream>
int main(){
    std::fstream inputoutputobj("language.txt"); //fstream hyat input and output function doni astat 
    //ha ek generic class ahe hyat reading and writing doni kru shakto

    //Reading
    std::string ReadData;
    while(inputoutputobj){
        getline(inputoutputobj,ReadData);
        std::cout<<ReadData<<std::endl;
    }

    //writing
    inputoutputobj<<"Angular Js\n";
    inputoutputobj<<"PHP\n";
    //writing nhi zal tr tyachya seekg fun vaprav lagel


    inputoutputobj.close();
}