//File Handling
//write function 
//use ofstream class means output

#include<iostream>
#include<fstream> //this header file use in file handling
//1st way constructor
//by using constructor

int main(){
    std::ofstream outputobj ("language.txt");  //hyani ek txt file create zali
    //parameter constructor use kela ahe jo internally asto
    //use std because ofstream is a standard class

    outputobj<<"C\n";
    outputobj<<"DS\n"; //data write kela ahe
    outputobj<<"CPP\n"; 
    outputobj<<"JAVA\n";
    outputobj<<"Python\n";
    outputobj<<"NodeJs\n";

    outputobj.close();
    std::ofstream outputobj1("language.txt",std::ios::app);
    outputobj1<<"AngularJS\n";
}
