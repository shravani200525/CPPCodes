//read function

#include<iostream>
#include<fstream>
//constructor
int main(){
    std::ifstream inputobj("friends.txt"); 
    //std::ifstream inputobj1("language.txt");
    std::string ReadData;
    //std::string Read;

    while(inputobj,inputobj1){
        getline(inputobj,ReadData);
       // getline(inputobj1,Read);
        //std::cout<<Read<<std::endl;
        std::cout<<ReadData<<std::endl;
    }
    inputobj.close();
    inputobj1.close();
}