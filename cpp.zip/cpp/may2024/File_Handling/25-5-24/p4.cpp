#include<iostream>
#include<fstream>

int main(){
    //input class
    std::ifstream inputobj("friends.txt");
    //output class
    std::ofstream outputobj("games.txt"); //new file create keli ani tyat previous file cha data takla
    //one variable
    std::string bowl;
    while(inputobj){
        getline(inputobj,bowl);
        //std::cout<<bowl<<std::endl; //console vr print zal
        outputobj<<bowl<<std::endl; //he as kelyavr 1st file madhla data new file madhi gela
    }
    outputobj.close();
    inputobj.close();
}
