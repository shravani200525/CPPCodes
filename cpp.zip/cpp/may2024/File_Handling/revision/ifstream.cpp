#include<iostream>
#include<fstream>
int main(){
    std::ifstream iobj ("movie.txt");
    std::string read;
    while(iobj){
        getline(iobj,read);
        std::cout<<read<<std::endl;
    }
    iobj.close();
}