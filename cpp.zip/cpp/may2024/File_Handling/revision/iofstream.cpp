#include<iostream>
#include<fstream>
int main(){
    std::ifstream iobj ("movie.txt");
    std::ofstream ofobj("song.txt");

    std::string read;
    while(iobj){
        getline(iobj,read);
        // std::cout<<read<<std::endl;
        ofobj<<read<<std::endl;
    }
    iobj.close();
    ofobj.close();
}