#include<iostream>
#include<fstream>

int main(){
    std::ofstream ofobj;
    ofobj.open("actor.txt");

    ofobj<<"karan kundra"<<std::endl;
    ofobj<<"sharad malhotra"<<std::endl;
    ofobj<<"ritesh deshmukh"<<std::endl;
    
    ofobj.close();
}