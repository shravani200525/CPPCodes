#include<iostream>
#include<fstream>
int main(){
    std::ifstream iobj;
    iobj.open("movie.txt");

    std::string data;
    while(iobj){
        getline(iobj,data);
        std::cout<<data<<std::endl;
    }
    iobj.close();
}