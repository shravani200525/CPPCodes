#include<iostream>
#include<fstream>
int main(){
    std::fstream inopobj ("movie.txt");
    //input
    std::string read;
    while(inopobj){
        getline(inopobj,read);
        std::cout<<read<<std::endl;
    }
    //output
    
    inopobj<<"LoveStory";
    inopobj<<"Majli";
    std::cout<<read<<std::endl;
    inopobj.close();
}