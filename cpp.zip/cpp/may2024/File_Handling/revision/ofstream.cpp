//doni hou shakt input operation pn and output operation pn

#include<iostream>
#include<fstream>
int main()
{
    std::ofstream opobj ("movie.txt");
    opobj<<"shiddat"<<std::endl;
    opobj<<"radhe_shyam"<<std::endl;
    opobj<<"yjhd"<<std::endl;
    
    opobj.close();

    // std::cout<<inopobj<<std::endl;
}