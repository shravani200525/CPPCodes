#include<iostream>
#include<fstream>
int main(){
    std::ifstream ifobj ("actor.txt");
    std::ofstream ofobj ("acteress.txt");

    ofobj<<"Alia Bhatt"<<std::endl;
    ofobj<<"kiara advani"<<std::endl;

    std::string readData;
    while(ifobj){
        getline(ifobj,readData);
        ofobj<<readData<<std::endl;
        std::cout<<readData<<std::endl;
    }
   
    ofobj.close();
    ifobj.close();
}