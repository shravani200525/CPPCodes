//subscript operator overloaded

#include<iostream>
class Demo
{
    public:
    int arr[5] = {10,20,30,40,50}; //array la size dili ata he work honar

    int operator[](int index)
    {
        return(arr[index]);
    }
};
int main()
{
    Demo obj;
    std::cout<<obj[1]<<std::endl; //hith no match chi error yete tr te talyanasathi operator[] function lihav lagel

    std::cout<<obj[7]<<std::endl; //garbage value
}
/*
20
1311638521
*/