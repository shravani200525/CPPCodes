//predefined exception

#include<exception>
#include<iostream>
int main()
{
    try{
        int size = -2;
        int *arr = new int [size];
    }
    catch(std::bad_alloc& obj){ //bad_alloc ha ek class ahe jo exception class cha child ahe
        std::cout<<obj.what()<<std::endl; //what he ek method ahe jyat already lihilele msg print hotat
    }
}
//std::bad_array_new_length