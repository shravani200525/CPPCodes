//Userdefined Exception
//6th scenario of copy constructor

#include<iostream>
class Indexinvalid
{
    std::string msg;
    public:
        Indexinvalid(std::string msg){
            this->msg=msg;
        }
        std::string getmsg()
        {
            return(msg);
        }
        Indexinvalid(const Indexinvalid& ref)
        {
            std::cout<<"copy constructor"<<std::endl;
        }
};
class Demo{
    int arr[5]={10,20,30,40,50};
    public:
        int arrlen(){ //fun to calculate length of the array
            return(sizeof(arr) / sizeof(int));

        }
        int operator[](int index)
        {
            if(index < 0 || index >= arrlen())
            {
                throw Indexinvalid ("Bad index");
            }
            return(arr[index]);
        }
};
int main()
{
    Demo obj;
    int index;
    std::cout<<"enter index"<<std::endl;
    std::cin>> index;

    try{
        std::cout<<obj[index]<<std::endl;

    }
    catch(Indexinvalid  obj) //call copy constructor
    //jr(Indexinvalid & obj) he as lihil tr copy constructor la call janar nhi
    {
        std::cout<<"exception occured"<< obj.getmsg() <<std::endl;
    }
}