//Restrict to function
#include<iostream>
class Demo
{
    int n1;
    public:
    Demo(int n1)
    {
        this->n1 = n1;
    }
    void fun(int n1) throw(int,char) //hith throw madhi restrictioin lavali to fakt int and float case lach execute krnr
    //he throw(int,char) he as lihil tr new cpp version error deto 
    //error: ISO C++17 does not allow dynamic exception specifications
    //tr he execute karayla cpp version 03 use karav lagel
    {
        switch(n1)
        {
            case 1:
                throw 10;
                break;
            case 2:
                throw 'a';
                break;
            case 3:
                throw 2.25;
                break;
            default:
                std::cout<<"wrong"<<std::endl;
                break;
        }
    }
};

int main()
{
    int n1;
    std::cout<<"enter a number"<<std::endl;
    std::cin>>n1;

    Demo obj(n1);
    try{
        obj.fun(n1);
    }
    catch(int n1)
    {
        std::cout<<"int handled"<<std::endl;
    }
    catch(char ch)
    {
        std::cout<<"char handled"<<std::endl;
    }
    catch(float f)
    {
        std::cout<<"float handled"<<std::endl;
    }

}
/*
output
enter a number
1
int handled
enter a number
2
char handled
enter a number
3
terminate called after throwing an instance of 'double'
Aborted
enter a number
5
wrong
*/