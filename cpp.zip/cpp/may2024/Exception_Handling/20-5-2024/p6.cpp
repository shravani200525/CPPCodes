#include<iostream>
class Demo
{
    int arr[5] = {10,20,30,40,50};
    public:
        int arrLen()
        {
            return (sizeof(arr) / sizeof(int));
        }
        int operator[] (int index)
        {
            if(index < 0 || index >= arrLen())
            {
                throw index;
                return(arr[index]);
            }
        }
};
int main()
{
    Demo obj;
    int index;
    std::cout<<"enter value"<<std::endl;
    std::cin>>index;

    try{
        std::cout<<obj[index]<<std::endl;
    }
    catch(int n1)
    {
        std::cout<<"exception occured"<<std::endl;
    }
}