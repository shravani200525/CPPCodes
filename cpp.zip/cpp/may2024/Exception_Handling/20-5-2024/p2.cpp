//rethrow exception

#include<iostream>
class Demo{
    public:
        void searchElement(int arr[],int size,int element)
        {
            int flag=0;
            int i;
            for(i=0;i<size;i++)
            {
                if(arr[i]==element)
                {
                    flag=1;
                    break;
                }
            }
            try{
                if(flag==1)
                {
                    std::cout<<"element found in index"<<std::endl;
                }
                else{
                    throw "element not found";
                }
            }
            catch(const char* str)
            {
                std::cout<<str<<std::endl;
                throw; //hith rethrow kelyamule element jr found nasl tr te 2vela print hot mhnaje tyala 2vela call jato
            }
        }
};
int main()
{
    Demo obj;
    int arr[]={10,20,30,40,50};
    int element;
    std::cout<<"enter element"<<std::endl;
    std::cin>>element;
    int size = sizeof(arr) / sizeof(int); //hith array chi size print hotiye 5 karan 20/4 = 5
    //mhnun size 5 print zali
    std::cout<<"size = "<<size<<std::endl;

    try{
        obj.searchElement(arr,size,element);
    }
    catch(const char *str){
        std::cout<<"catch in main:-"<<str<<std::endl;
        
    }
}
/*
enter element
20
size = 5
element found in index

jr element found nasl tr..
enter element
100
size = 5
element not found
catch in main:-element not found
*/