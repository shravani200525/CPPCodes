//subscript operator overload

#include<iostream>
class Demo
{
    public:
    int arr[] = {10,20,30,40,50}; // jr arr la size nhi dili tr error yeti 
    //cpp  madhi arr[] size den compulsory ahe
    //error: flexible array member ‘Demo::arr’ in an otherwise empty ‘class Demo’


};
int main()
{
    Demo obj;
    std::cout<<obj[1]<<std::endl; //no match chi error
    // error: no match for ‘operator[]’ (operand types are ‘Demo’ and ‘int’)
}