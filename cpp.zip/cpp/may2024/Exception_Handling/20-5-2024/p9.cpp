#include<exception>
#include<iostream>
int main()
{
    try{
        int size = -2;
        int *arr = new int [size];
    }
    catch(std::exception& obj) // ha ek exception parent class ahe jo already lihilela ahe
    {
        std::cout<<obj.what()<<std::endl;
    }
}
//std::bad_array_new_length