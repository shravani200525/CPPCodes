#include<iostream>
#include<cmath>
int main()
{
    int n1;
    std::cout<<"start"<<std::endl;
    std::cout<<"enter value"<<std::endl;

    std::cin>> n1;
    std::cout<<sqrt(n1) <<std::endl; //jr (-) madhi value dili tr nan exception yeto mhnaje not a number ani 
    //sqrt kadaycha asl tr cmath hi header file vapratat c use kela because hi clanguage chi file ahe mhnun <cmath>
    std::cout<<"end"<<std::endl;
    return(0);
}

/*
output
start
enter value
-10
-nan
end
*/