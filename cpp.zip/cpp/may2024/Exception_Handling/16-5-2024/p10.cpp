#include<iostream>
class demo
{
    public:

    int n1 =10;
    int n2=0;
    demo(int n1,int n2)
    {
        this->n1=n1;
        this->n2=n2;
        std::cout<<"parameterized constructor"<<std::endl;
    }
    void fun()
    {
        std::cout<<"start fun"<<std::endl;
        try{
            if(n2!=0)
            {
                std::cout<< n1 / n2 <<std::endl; //exception class madhi handled kel
            }else{
                throw "divide/zero";
            }
        }
        catch(const char* str)
        {
            std::cout<<"handled"<<std::endl;
        }
    }
};
int main()
{
    std::cout<<"main start"<<std::endl;
    int n1,n2;
    demo obj(n1,n2);
    obj.fun();
    std::cout<<"end main"<<std::endl;
    return(0);
}
/*output
main start
parameterized constructor
start fun
handled
end main
*/