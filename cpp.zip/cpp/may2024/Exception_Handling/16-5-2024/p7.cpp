//Exception handling for primitive data type
//3keywords use try,catch,throw

#include<iostream>
int main()
{
    std::cout<<"start"<<std::endl;
    try{
        throw "error";
    }catch(const char* str){ //it will works because throw madhi string pass keli ahe ani match madhi const char* ghetlay 
    //because cpp madhi hi string const aste mhnun match kartana const char* takly
        std::cout<<"handled"<<std::endl;
    }
}
/*
output
start
handled
*/