//Exception handling for primitive data type
//3keywords use try,catch,throw

#include<iostream>
int main()
{
    std::cout<<"start"<<std::endl;
    try{
        throw "error";
    }catch(std::string str){ //it will not works because throw madhi string pass keli ahe
    //ani cpp madhi string hi const aste mhnun compiler ni process terminate keli 
        std::cout<<"handled"<<std::endl;
    }
    std::cout<<"end"<<std::endl;
}
/*
output
start
terminate called after throwing an instance of 'char const*'
Aborted
*/