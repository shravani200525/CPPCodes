#include<iostream>

void fun3()
{
    std::cout<<"start fun3"<<std::endl;
    throw -1; //hith fun3 madhi apn integer value throw kely pn tyach try and catch nhi lihilel mhnun to fakt start print krnr
    //mg to tyach try and catch shodhayla fun3 la jyani call kely tyachya kad jail tyat baghl try and catch ahe ka jr nasal tr fun2
    //la jyani call kely tyachya kad jail tyat baghal ahe ka jr nasl tr fun1 la jyani call kely tith jail ani mg main fun madhi tyala
    //try and catch bhetla tr tyani main fun cha end pn print kela 
    //ani baki fun cha nhi kela to check krtana ch to fun stack varun pop krun takto
    std::cout<<"end fun3"<<std::endl;
}
void fun2()
{
    std::cout<<"start fun2"<<std::endl;
    fun3();
    std::cout<<"start fun2"<<std::endl;
}
void fun1()
{
    std::cout<<"start fun1"<<std::endl;
    fun2();
    std::cout<<"end fun1"<<std::endl;
}

int main()
{
    std::cout<<"start main"<<std::endl;
    try
    {
        fun1();
    }
    catch(...)
    {
        std::cout<<"handled"<<std::endl;
    }
    std::cout<<"end main"<<std::endl;
}
/*
output
start main
start fun1
start fun2
start fun3
handled
end main
*/