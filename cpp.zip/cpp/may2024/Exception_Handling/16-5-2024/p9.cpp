#include<iostream>
int main()
{
    std::cout<<"start main"<<std::endl;
    int n1=10;
    int n2=0;  
    try{
        if(n2!=0)
        {
            std::cout<< n1 / n2 << std::endl; //hith 10 / 0 kel tr floating chi exception yeil tr te handle karnyasathi 
            //ha code lihila mhnun tyani handled msg print kela 
        }else{
            throw"divide/zero";
        }
    }
        catch(const char* str)
        {
            std::cout<<"handled"<<std::endl;
        }
    
    std::cout<<"end main"<<std::endl;
    return(0);
}
/*
output
start main
handled
end main
*/