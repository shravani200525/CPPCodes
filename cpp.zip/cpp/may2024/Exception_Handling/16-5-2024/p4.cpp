//Exception handling for primitive data type
//3keywords use try,catch,throw

#include<iostream>
int main()
{
    std::cout<<"start"<<std::endl;
    try{
        throw -1;
    }catch(char a){ //it will not work because hith apn throw integer kely ahe ani catch madhi char pathvaly tr to tyala match hot nhi 
    //mhanun process terminate hoti
        std::cout<<"handled"<<std::endl;
    }
    std::cout<<"end"<<std::endl;
}
/*
output
start
terminate called after throwing an instance of 'int'
Aborted
*/