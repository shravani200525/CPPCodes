//Exception handling for primitive data type
//3keywords use try,catch,throw

#include<iostream>
int main()
{
    std::cout<<"start"<<std::endl;
    try{ //try madhi risky code lihitat mhnaje jya line la exception yeu shakto to code try madhi lihaycha
        throw -1; //throw madhi aplyala je fekaycha ahe te lihaycha ast
    }catch(int a){  //catch (match) hyat jya type ch apn throw kel ahe tyacha type lihaycha jr integer value asl int etc 
        std::cout<<"handled"<<std::endl;
    }
}
/*
output
start
handled
*/