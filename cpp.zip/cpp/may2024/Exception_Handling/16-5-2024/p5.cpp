//Exception handling for primitive data type
//3keywords use try,catch,throw

#include<iostream>
int main()
{
    std::cout<<"start"<<std::endl;
    try{
        throw -1;
    }catch(...){ //it will work because hith apn generic vaprla ahe mhnje hyat jr apn kontya hi prakar ch throw kel tr to match krl
    //pn he(...) mostly use nhi karaycha
        std::cout<<"handled generic"<<std::endl;
    }
    std::cout<<"end"<<std::endl;
}
/*
output
start
handled generic
end
*/