//exception handling

#include<iostream>

int main()
{
    std::cout<<"start"<<std::endl;
    int n1,n2;
    std::cout<<"enter no"<<std::endl;
    std::cin>> n1 >> n2;

    std::cout<< n1 / n2 <<std::endl; //hith jar 10/0 kel tr 0 ni kontya no la divide hot nhi mhanun floating point cha exception yeto

    std::cout<<"end"<<std::endl;
    return(0);
}
/*
output
start
enter no
10
0
Floating point exception
*/