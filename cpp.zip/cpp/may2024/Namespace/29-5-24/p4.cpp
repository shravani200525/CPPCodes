// nested -> namespace chya at namespace

#include<iostream>
namespace pune{
    namespace katraj{
        int population = 1000;
        void display(){
            std::cout<<population<<std::endl;
        }
    }
}
namespace Nagpur{
    int populations = 5000;
    void details(){
        std::cout<<populations<<std::endl;
    }
}
int main(){
    pune::katraj::display();
    Nagpur::details();
}