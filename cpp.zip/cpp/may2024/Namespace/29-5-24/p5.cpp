//same namespace

#include<iostream>

namespace farmer{
    std::string fName ="Dagdu";
    float frev = 10.2f;
}
namespace farmer{
    void display(){
        std::cout<<"pune"<<std::endl;
    }
}
int main(){
    std::cout<<farmer::fName<<std::endl;
    std::cout<<farmer::frev<<std::endl;
    farmer::display();
}