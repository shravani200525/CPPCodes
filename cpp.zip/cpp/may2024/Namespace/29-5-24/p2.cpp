//types of namespace
//2nd Add header
//it can add our own header file

#include<iostream>
// #include<myheader.h> ->error
#include "myheader.h"

