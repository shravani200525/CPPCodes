//namespace is use to avoid ambiquety and confusion
//in some classes identifier name is same so that use namespace
//types of namespace
//1st Simple Namespace

#include<iostream>

//create own namespace

namespace pune
{
	int distpopulation = 1000;
	void display(){
		std::cout<<distpopulation<<std::endl;
	}
}//there is no semicolon
 

namespace Nagpur
{
	int distpopulation = 2000;
	void display()
	{
		std::cout<<distpopulation<<std::endl;
	}
} // there is no semicolon
  
int main()
{
	pune::display();
	Nagpur::display(); //in namespace obj is not created call the fun in this way by using scope resoulution(::)
	//and function name
}
