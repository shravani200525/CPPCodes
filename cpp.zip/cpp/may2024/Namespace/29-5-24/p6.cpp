//alises namespace
//hyani jr namespace ch name moth asl tr hyani chot krta yet

#include<iostream>
namespace farmer{
    std::string fName ="Dagdu";
    float frev = 10.2f;
}
namespace farmer{
    void display(){
        std::cout<<"pune"<<std::endl;
    }
}
int main(){
    namespace frm = farmer; //farmer la short name frm dil
    std::cout<<frm::fName<<std::endl;
    std::cout<<frm::frev<<std::endl;
    frm::display();
}