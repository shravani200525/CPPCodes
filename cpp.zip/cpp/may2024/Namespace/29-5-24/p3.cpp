#include<iostream>
// using namespace std; it can't use 

namespace pune{
    int distpopulation = 1500;
    void display(){
        std::cout<<distpopulation<<std::endl;
    }
}
namespace Nagpur{
    int distpopulation = 7800;
    void display(){
        std::cout<<distpopulation<<std::endl;
    }
}
int main()
{
    pune::display();
    Nagpur::display();
}