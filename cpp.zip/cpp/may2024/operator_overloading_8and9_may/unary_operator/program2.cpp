//postfix

#include<iostream>
class demo{

    int n1=10;
    public:
    int operator++(demo& obj)
    {
        return(++obj.n1);
    }
    int operator++()
    {
        int temp=n1;
        n1=n1+1;
        return(temp);
    }
};
int main()
{
    demo obj;
    std::cout<<++obj << std::endl;
    std:: cout<< obj++ << std::endl;
    std::cout<< obj << std::endl;
}