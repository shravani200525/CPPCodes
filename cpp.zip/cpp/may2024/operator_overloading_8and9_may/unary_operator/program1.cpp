//unary operator overloaded by using friend function

#include<iostream>
class demo
{
    int n1=10;
    friend int operator++(demo& obj)
    {
        return(++obj.n1);
    }
};
int main()
{
    demo obj;
    std::cout<< ++obj << std::endl;
}
//11