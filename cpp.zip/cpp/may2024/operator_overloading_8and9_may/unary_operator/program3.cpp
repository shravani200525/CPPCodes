
#include<iostream>
class demo{
    int n1=10;
    public:
    int operator++()
    {
        return(++n1);
    }
    int operator++(int)
    {
        int temp=n1;
        n1=n1+1;
        return(temp);
    }
    friend std::ostream& operator<< (std::ostream& shravani,const demo& obj)
    {
        shravani<<obj.n1;
        return(shravani);
    }
};
int main()
{
    demo obj;
    std::cout<<++obj << std::endl;//11
    std:: cout<< obj++ << std::endl;//11
    std::cout<< obj << std::endl;//12
}