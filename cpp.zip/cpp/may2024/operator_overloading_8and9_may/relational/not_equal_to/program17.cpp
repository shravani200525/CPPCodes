//operator overloading by using normal function
//Relational operator(!=)
#include<iostream>
class NotEqual
{
    int n1;
    public:
    NotEqual(int n1)
    {
        this->n1=n1;
    }
    int getN1()const
    {
        return(n1);
    }
};
int operator!=(const NotEqual& obj1,const NotEqual& obj2)
{
    return(obj1.getN1() != obj2.getN1());
}
int main()
{
    NotEqual obj1(2);
    NotEqual obj2(1);
    std:: cout<< (obj1 != obj2) << std::endl;
}