//operator overloading by using friend function
//Relational operator(!=)
#include<iostream>
class NotEqual{
    int n1;
    public:
    NotEqual(int n1)
    {
        this->n1=n1;
    }
    friend int operator!= (const NotEqual& obj1, const NotEqual& obj2){
        return(obj1.n1 != obj2.n1);
    }
};
int main()
{
    NotEqual obj1(40);
    NotEqual obj2(90);
    std::cout<< (obj1 != obj2) << std::endl;
}