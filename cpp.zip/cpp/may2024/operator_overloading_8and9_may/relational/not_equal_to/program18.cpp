//operator overloading by using member function
//Relational operator(!=)
#include<iostream>
class NotEqual
{
    int n1;
    public:
    NotEqual(int n1)
    {
        this->n1=n1;
    }
    int operator!=(const NotEqual& obj2)
    {
        return(this->n1 != obj2.n1);
    }
};
int main()
{
    NotEqual obj1(1);
    NotEqual obj2(1);
    std::cout<< (obj1 != obj2) << std::endl;
}