//operator overloading by using normal function
//Relational operator(<)
#include<iostream>
class LessThan
{
    int n1;
    public:
    LessThan(int n1)
    {
        this->n1=n1;
    }
    int getN1()const
    {
        return(n1);
    }
};
int operator<(const LessThan& obj1,const LessThan& obj2)
{
    return(obj1.getN1() < obj2.getN1());
}
int main()
{
    LessThan obj1(2);
    LessThan obj2(1);
    std:: cout<< (obj1 < obj2) << std::endl;
}