//operator overloading by using normal function
//Relational operator(>=)
#include<iostream>
class demo
{
    int n1;
    public:
    demo(int n1)
    {
        this->n1=n1;
    }
    int getN1()const
    {
        return(n1);
    }
};
int operator>=(const demo& obj1,const demo& obj2)
{
    return(obj1.getN1() >= obj2.getN1());
}
int main()
{
    demo obj1(2);
    demo obj2(1);
    std:: cout<< (obj1 >= obj2) << std::endl;
}