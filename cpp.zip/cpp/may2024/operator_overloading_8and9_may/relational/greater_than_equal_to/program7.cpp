//operator overloading by using friend function
//Relational operator(>=)
#include<iostream>
class demo{
    int n1;
    public:
    demo(int n1)
    {
        this->n1=n1;
    }
    friend int operator>= (const demo& obj1, const demo& obj2){
        return(obj1.n1 >= obj2.n1);
    }
};
int main()
{
    demo obj1(40);
    demo obj2(90);
    std::cout<< (obj1 >= obj2) << std::endl;
}