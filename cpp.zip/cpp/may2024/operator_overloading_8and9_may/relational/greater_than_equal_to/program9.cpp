//operator overloading by using member function
//Relational operator(>=)
#include<iostream>
class demo
{
    int n1;
    public:
    demo(int n1)
    {
        this->n1=n1;
    }
    int operator>=(const demo& obj2)
    {
        return(this->n1 >= obj2.n1);
    }
};
int main()
{
    demo obj1(1);
    demo obj2(0);
    std::cout<< (obj1 >= obj2) << std::endl;
}