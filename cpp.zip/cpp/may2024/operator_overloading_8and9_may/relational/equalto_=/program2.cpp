//operator overloading by using normal function
//Relational operator(==)
#include<iostream>
class Equal{
    int n1;
    public:
    Equal(int n1)
    {
        this->n1=n1;
    }
    int getN1()const
    {
        return(n1);
    }
};
int operator==(const Equal& obj1,const Equal& obj2)
{
    return(obj1.getN1() == obj2.getN1());
}
int main()
{
    Equal obj1(10);
    Equal obj2(20);
    std::cout << (obj1 == obj2) << std::endl;
}