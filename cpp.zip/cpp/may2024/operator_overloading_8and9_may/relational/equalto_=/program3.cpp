//operator overloading by using member function
//Relational operator(==)
#include<iostream>
class Equal
{
    int n1;
    public:
    demo(int n1)
    {
        this->n1=n1;
    }
    int operator==(const Equal& obj2)
    {
        return(this->n1 == obj2.n1);
    }
};
int main()
{
    Equal obj1(1);
    Equal obj2(2);
    std::cout<< (obj1==obj2) << std::endl;
}