//operator overloading by using member function
//Relational operator(<=)
#include<iostream>
class LessThan
{
    int n1;
    public:
    LessThan(int n1)
    {
        this->n1=n1;
    }
    int operator<=(const LessThan& obj2)
    {
        return(this->n1 <= obj2.n1);
    }
};
int main()
{
    LessThan obj1(1);
    LessThan obj2(1);
    std::cout<< (obj1 <= obj2) << std::endl;
}