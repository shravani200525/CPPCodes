//operator overloading by using friend function
//Relational operator(<=)
#include<iostream>
class LessThan{
    int n1;
    public:
    LessThan(int n1)
    {
        this->n1=n1;
    }
    friend int operator<= (const LessThan& obj1, const LessThan& obj2){
        return(obj1.n1 <= obj2.n1);
    }
};
int main()
{
    LessThan obj1(40);
    LessThan obj2(90);
    std::cout<< (obj1 <= obj2) << std::endl;
}