//operator overloading by using member function
//Relational operator(>)
#include<iostream>
class greater_than
{
    int n1;
    public:
    greater_than(int n1)
    {
        this->n1=n1;
    }
    int operator>(const greater_than& obj2)
    {
        return(this->n1 > obj2.n1);
    }
};
int main()
{
    greater_than obj1(1);
    greater_than obj2(0);
    std::cout<< (obj1 > obj2) << std::endl;
}