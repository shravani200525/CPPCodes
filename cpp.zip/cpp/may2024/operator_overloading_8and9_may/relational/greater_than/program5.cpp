//operator overloading by using normal function
//Relational operator(>)
#include<iostream>
class greater_than
{
    int n1;
    public:
    greater_than(int n1)
    {
        this->n1=n1;
    }
    int getN1()const
    {
        return(n1);
    }
};
int operator>(const greater_than& obj1,const greater_than& obj2)
{
    return(obj1.getN1() > obj2.getN1());
}
int main()
{
    greater_than obj1(2);
    greater_than obj2(5);
    std:: cout<< (obj1 > obj2) << std::endl;
}