//insertion operator overloaded by using normal function

#include<iostream>
class Insertion
{
    int n1=100;
    int n2=200;
    public:
    std::ostream& operator<< (std::ostream& out,const Insertion& obj1)
    {
        out<< obj1.n1<< std::endl;
        out<< obj1.n2;
        return(out);
    }   
};

int main()
{
    Insertion obj;
    std::cout<< obj << std::endl;
}
//not worked