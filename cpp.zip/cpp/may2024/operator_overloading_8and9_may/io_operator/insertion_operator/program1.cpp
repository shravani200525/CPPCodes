//insertion operator overloaded by using frined function
//insertion operator(<<)

#include<iostream>
class Insertion
{
    int n1=10;
    int n2=20;
    friend std::ostream& operator<<(std::ostream& out, const Insertion& obj)
    {
        out<< obj.n1 << std::endl; // internally operator(out,int)
        out<< obj.n2; // internally operator(out, int)
        return(out);
    }
};
int main()
{
    Insertion obj1;
    std:: cout << obj1 << std::endl;
    //operator << (out.obj1);
}

//output= 10 20