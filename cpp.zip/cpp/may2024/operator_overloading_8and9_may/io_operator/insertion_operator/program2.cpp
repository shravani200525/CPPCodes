//insertion operator overloaded by using normal function

#include<iostream>
class Insertion
{
    int n1=100;
    int n2=200;
    public:
        int getN1()const
        {
            return(n1);
        }
        int getN2()const{

            return(n2);
        }
};
std::ostream& operator<< (std::ostream& out,const Insertion& obj1)
{
    out<< obj1.getN1()<< std::endl;
    out<< obj1.getN2();
    return(out);
}
int main()
{
    Insertion obj;
    std::cout<< obj << std::endl;
}
//output=100 200