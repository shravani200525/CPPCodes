//extraction operator overloaded by using friend function
//extraction operator(>>)

#include<iostream>
class extraction
{
    
    int n1;
    int n2;
    friend std::istream& operator>>(std::istream& in,extraction& obj)
    {
        in>>obj.n1;
        in>>obj.n2;
        return(in);
    }
    public:
    void printdata()
    {
        std::cout<<n1<<std::endl;
        std::cout<<n2<<std::endl;
    }
};
int main()
{
    
    int n1;
    int n2;
    extraction obj1;
    std::cout<<"enter values"<<std::endl;
    std::cin>>obj1;
    obj1.printdata();
}
//output=10 20