//extraction operator overload by using normal function
#include<iostream>
class extraction
{
    int n1;
    int n2;
    public:
    int getn1()const{
        return(n1);
    }
    int getn2()const{
        return(n2);
    }
    void getdata()
    {
        std::cout<< n1 << n2 << std::endl;
    }

};
std::istream& operator>>(std::istream& in,extraction& obj)
{
    in>> obj.getn1();//error:no match
    in>> obj.getn2();
    return(in);
}
int main()
{
    int n1;
    int n2;
    extraction obj;
    std::cout<< "enter value"<<std::endl;
    std::cin>>obj;
    obj.getdata();
//error: no match 