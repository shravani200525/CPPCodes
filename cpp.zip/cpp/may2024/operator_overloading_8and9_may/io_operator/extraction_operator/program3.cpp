//extraction operator overloaded by using member function

#include<iostream>
class extraction
{
    int n1;
    int n2;
    public:
    std::istream& operator>> (std::istream& inxx,const extraction& obj1)
    {
        in >> obj1.n1;
        in >> obj1.n2;
        return(in);
    }   
};

int main()
{
    int n1;
    int n2;
    extraction obj;
    std::cout<<"enter value"<<std::endl;
    std::cin>>obj;
    //std::cout<< (obj) << std::endl;
}
//not worked