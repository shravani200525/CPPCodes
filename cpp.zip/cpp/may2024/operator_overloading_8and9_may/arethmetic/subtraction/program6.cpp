//operator overloading by using member function
//Arethmetic Operator(-)

#include<iostream>
class Minus
{
    int n1;
    public:
    Minus(int n1)
    {
        this->n1=n1;
    }
    int operator-(const Minus& obj2)
    {
        return(this->n1-obj2.n1);
    }
};
int main()
{
    Minus obj1(50);
    Minus obj2(20);
    std::cout<< obj1-obj2<<std::endl;
}

/*
internally
prototype
operator-(obj1,obj2);
int operator+(Minus obj1,Minus obj2)
{
    return(obj1.n1-obj2.n1);
}
*/
//output=30