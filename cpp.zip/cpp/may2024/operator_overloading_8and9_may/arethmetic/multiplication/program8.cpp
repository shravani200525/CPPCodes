//operator overloading by using normal function
//Arethmetic operator(*)

#include<iostream>
class Multiplication
{
    int n1;
    public:
    Multiplication(int n1)
    {
        this->n1=n1;
    }
    int getN1()const{
        return(n1);
    }
};
int operator*(const Multiplication& obj1,const Multiplication& obj2)
{
    return(obj1.getN1() * obj2.getN1());
}

int main()
{
    Multiplication obj1(3);
    Multiplication obj2(4);
    std::cout << obj1 * obj2 << std::endl;
}

/*
internally
prototype
operator*(obj1,obj2);
int operator*(Multiplication obj1,Multiplication obj2)
{
    return(obj1.n1*obj2.n1);
}
*/
//output=12