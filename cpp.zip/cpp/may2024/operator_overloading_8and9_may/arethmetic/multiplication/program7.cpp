//operator overloading by using friend function
//Arethmetic Operator(*)

#include<iostream>
class Multiplication
{
    int n1;
    public:
    Multiplication(int n1)
    {
        this->n1=n1;
    }
    friend int operator*(const Multiplication& obj1,const Multiplication& obj2)
    {
        return(obj1.n1*obj2.n1);
    }
};
int main()
{
    Multiplication obj1(2);
    Multiplication obj2(5);
    std::cout<< obj1 * obj2 << std::endl;
}

/*
internally
prototype
operator*(obj1,obj2);
int operator*(Multiplication obj1,Multiplication obj2)
{
    return(obj1.n1*obj2.n1);
}
*/
//output=10