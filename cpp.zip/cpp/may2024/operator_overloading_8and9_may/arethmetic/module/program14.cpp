//operator overloading by using normal function
//Arethmetic operator(%)
#include<iostream>
class Mod
{
    int n1;
    public:
        Mod(int n1)
        {
            this->n1=n1;
        }
        int getN1()const{
            return(n1);
        }
};
int operator%(const Mod& obj1,const Mod& obj2)
{
    return(obj1.getN1() % obj2.getN1());
}
int main()
{
    Mod obj1(10);
    Mod obj2(20);
    std::cout<< obj1 % obj2 << std::endl;
}
//internally obj1 % obj2 is..
    //operator%(obj1,obj2); this is prototype
    //main body
    // int operator%(Mod obj1,Mod obj2)
    //{
        //return(obj1.n1%obj2.n1);
    //}
//output=10