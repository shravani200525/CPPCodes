//operator overloading by using member function
//Arethmetic operator(+)

#include<iostream>
class Demo
{
    int n1;
    public:
    Demo(int n1)
    {
        this->n1=n1;
    }
    int operator+(const Demo& obj2)
    {
        return(this->n1+obj2.n1);
    }
};
int main()
{
    Demo obj1(20);
    Demo obj2(20);
    std::cout<< obj1+obj2<<std::endl;

/*
internally
prototype
operator+(obj1,obj2);
int operator+(Demo obj1,Demo obj2)
{
    return(obj1.n1+obj2.n1);
}
*/
}
//output:40