//operator overloading by using friend function
//Arethmetic Operator(+)

#include<iostream>
class Demo
{
    int n1;
    public:
        Demo(int n1)
        {
            this->n1=n1;
        }
        private:
        friend int operator+(const Demo& obj1,const Demo& obj2)
        {
            return(obj1.n1+obj2.n1);
        }
};
int main()
{
    Demo obj1(10);
    Demo obj2(20);
    std::cout<< obj1 + obj2 << std::endl;

    //internally obj1 + obj2 is..
    //operator+(obj1,obj2); this is prototype
    //main body
    // int operator+(Demo obj1,Demo obj2)
    //{
        //return(obj1.n1+obj2.n1);
    //}
}

//output:30