//operator overloading by using normal function
//Arethmetic operator(+)

#include<iostream>
class Demo
{
    int n1;
    public:
    Demo(int n1)
    {
        this->n1=n1;
    }
    public:
    int getN1()const
    {
        return (n1);
    }
};
int operator+(const Demo& obj1,const Demo& obj2)
{
    return(obj1.getN1() + obj2.getN1()); 
}
int main()
{
    Demo obj1(10);
    Demo obj2(20);
    std::cout<< obj1 + obj2 << std::endl;
}
/*
internally
prototype
operator+(obj1,obj2);
int operator+(Demo obj1,Demo obj2)
{
    return(obj1.n1+obj2.n1);
}
*/
//output= 30