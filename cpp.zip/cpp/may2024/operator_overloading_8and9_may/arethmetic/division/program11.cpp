//operator overloading by using normal function
//Arethmetic operator(/)

#include<iostream>
class Division
{
    int n1;
    public:
    Division(int n1)
    {
        this->n1=n1;
    }
    int getN1()const{
        return(n1);
    }
};
int operator/(const Division& obj1,const Division& obj2)
{
    return(obj1.getN1() / obj2.getN1());
}
int main()
{
    Division obj1(5);
    Division obj2(4);
    std::cout<< obj1 / obj2 << std::endl;
}
/*
internally
prototype
operator/(obj1,obj2);
int operator/(Division obj1,Division obj2)
{
    return(obj1.n1/obj2.n1);
}
*/
//output= 1