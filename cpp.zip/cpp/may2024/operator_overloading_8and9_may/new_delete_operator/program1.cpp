//new operator overloaded

#include<iostream>
class demo
{
    int n1=10,n2=20;
    public:
    void getData()
    {
        std::cout<< n1 << std::endl;
        std::cout << n2 << std::endl;
    }
    friend void* operator new(size_t size)
    {
        std::cout<< "in new function call"<<std::endl;
        void* ptr = malloc (size);
        return(ptr);
    }
    void operator delete (void* ptr)
    {
        std:: cout<< "in delete"<<std::endl;
        free(ptr);
    }
};
int main()
{
    demo *obj = new demo();
    obj->getData();
    delete(obj);
}
