#include<iostream>

class demo
{
    public:
    //constructor
    demo()
    {
        std::cout << this << std::endl;
        std:: cout << "no argument constructor"<<std::endl;
    }
};
int main()
{

    demo obj;
    std::cout << &obj << std::endl;
}