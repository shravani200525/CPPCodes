//types of constructor
//1.no argument constructor
//2.parameterized constructor
//3.copy constructor

#include<iostream>
class demo{
    public:
    //default or no argument constructor

    demo()
    {
        std:: cout << "no argument" << std::endl;
    }

    //parameterized constructor

    demo(int n1){
        std:: cout << "parameterized" << std::endl;
    }

    //copy constructor

    demo (demo &obj)
    {
        std:: cout << "copy constructor" << std::endl;
    }
};

int main()
{
    demo obj1;//call no argument constructor
    demo obj2(10);//call parameterized constructor
    //demo obj3(obj1);//call the copy constructor
    //interanally
    demo obj3=obj1;

    demo obj5;//no argument call
    obj5=obj1;//this is only assignement not a initialization
}