//constructor by using this pointer

#include<iostream>

class demo{
    //by default private
    int n1=10;
    int n2 = 20;

    public:
    //no argument constructor

    demo()
    {
        std :: cout << "no argument"<< std::endl;
        std:: cout << n1 << std::endl;
        std:: cout << n2 << std:: endl;
    }
    //parameterized constructor

    demo(int n1,int n2){
        this -> n1 = n1;
        this -> n2 = n2;

        std :: cout << "parameterized"<< std::endl;
        std :: cout << n1<< std::endl;
        std :: cout << n2<< std::endl;
    }
};

int main()
{
    demo obj1;
    int n1,n2;
    std:: cout << "enter value:"<<std::endl;
    std:: cin>> n1>> n2;
    demo obj2(n1,n2);
    return(0);          
}