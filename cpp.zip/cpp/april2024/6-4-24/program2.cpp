#include<iostream>
class demo{
    public:
    demo(int n1)
    {
        std::cout<< " no argument" << std::endl;
    }
};
int main()
{
    demo obj;
}