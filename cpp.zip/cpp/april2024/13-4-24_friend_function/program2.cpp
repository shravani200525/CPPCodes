#include<iostream>
class demo{
    private:
        int n1 = 10;
    protected:
        int n2 = 20;
    public:
    //constructor
        demo(){
            std:: cout << "in the no argument constructor"<<std::endl;
        }
    void getinfo(){
        std:: cout << n1 << std::endl;
        std:: cout << n2 << std::endl;
    }
    friend void getdetails(const demo &obj);
};
void getdetails(const demo &obj){
    obj.n1 = 80; //value not change with the const keyword
    obj.n2 = 90; // value not change with the const keyword
    std:: cout << obj.n1 << std:: endl;
    std:: cout << obj.n2 << std::endl;
}
int main()
{
    demo obj1;
    getdetails(obj1);
}