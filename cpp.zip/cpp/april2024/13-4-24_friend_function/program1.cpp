//Friend Function and Friend Class
//1st scenario of friend function

#include<iostream>
class demo{
    private:
        int n1=10;
    protected:
        int n2=20;
    public:
    //constructor
        demo(){
            std:: cout << "in constructor" << std::endl;
        }
    void getinfo(){
        std:: cout << n1 << std::endl;
        std:: cout << n2 << std::endl;
    }
    friend void getdetails(demo &obj); //1st scenario
};
void getdetails(demo &obj){
    std::cout << obj.n1 << std::endl;
    std:: cout << obj.n2 << std::endl;
}

int main(){
    demo obj1;
    obj1.getinfo();
    getdetails(obj1);
}