//friend class 
//3rd scenario
#include<iostream>
class demo2;
class demo1{
    private:
        int n1=10;
    protected:
        int n2=20;
    public:
    //constructor
        demo1(){
            std:: cout << "in constructor" << std::endl;
        }
    void getinfo()
    {
        std:: cout << n1 << std::endl;
        std:: cout << n2 << std::endl;
    }
    friend class demo2;
};

class demo2{
    public:
    //constructor
        demo2(){
            std:: cout << "in constructor" << std::endl;
        }
    void getinfo1(demo1 &obj)
    {
        //std:: cout <<obj.n1  << std::endl;
        //std:: cout << obj1.n2 << std::endl;
        obj.getinfo();
    }
};
int main(){
    demo1 obj1;
    demo2 obj2;
    obj2.getinfo1(obj1);
}