//friend class
//2nd scenario 

#include<iostream>
class demo2;
class demo1{
    private:
        int n1=10;
    protected:
        int n2=20;
    public:
    //constructor
        demo1(){
            std:: cout << "in constructor" << std::endl;
        }
    void getinfo()
    {
        std:: cout << n1 << std::endl;
        std:: cout << n2 << std::endl;
    }
    friend void getdetails(const demo1 &obj,const demo2 &obj1); //2nd scenario
};

class demo2{
    
    private:
        int n3=90;
    protected:
        int n4=70;
    public:
    //constructor
        demo2(){
            std:: cout << "in constructor" << std::endl;
        }
    void getinfo1()
    {
        std:: cout << n3 << std::endl;
        std:: cout << n4 << std::endl;
    }
    friend void getdetails(const demo1 &obj,const demo2 &obj1);
};
void getdetails(demo1 &obj,demo2 &obj1){
        obj.getinfo();
        obj1.getinfo1();
}

int main(){
    demo1 obj3;
    demo2 obj2;
    getdetails(obj3,obj2);
}