#include<iostream>
class demo{
    public:
    //no argument constructor
    demo()
    {
        std::cout<< "no argument constructor" << std::endl;
    }
    //parameterized constructor
    demo(int n1,float n2){
        std:: cout << "parameterized constructor" << std::endl;
        std:: cout << n1 << std::endl;
        std:: cout << n2 << std ::endl;
    }
    //copy constructor
    demo(demo &obj){
        std::cout<< "copy constructor" << std::endl;
    }
};

demo getinfo(demo obj){
    demo obj10; //it call the no argument constructor
    return (obj10); //it call the copy constructor
}

int main(){
    demo obj1; // it call the no argument constructor
    demo obj2(10,5.2); //it call the parameterized constructor
    demo obj3(obj1); //it call the copy constructor
    getinfo(obj1); // it call the copy constructor
}