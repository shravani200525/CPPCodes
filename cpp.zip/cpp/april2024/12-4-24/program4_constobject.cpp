//const object

#include<iostream>
class demo{
    public:
    int n1=10;
    public:
    demo(){
        this -> n1 = 50;
        std::cout << "no argument constructor" << std::endl;
    }
     void getinfo()const{
        //this -> n1 = 1000;
        std::cout << n1 << std::endl;
    }
};
int main(){
    const demo obj;

    obj.getinfo();
}