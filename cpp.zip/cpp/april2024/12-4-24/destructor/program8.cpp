//destructor

#include<iostream>
class demo{
    public:
    //constructor
    demo(){
        std::cout<< "in no argument constructor" << std::endl;
    }
    //destructor
    ~demo(){
        std::cout<< "in destructor" << std::endl;
    }
};

int main()
{
    demo obj1;
    //object creating on heap
    demo *obj2 = new demo();
    std::cout<< "End main" << std::endl;
    //delete obj2;
    delete obj1;
}