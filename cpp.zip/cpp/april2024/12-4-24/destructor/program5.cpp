//destructor

#include<iostream>
class demo{
    public:
    int n1=10;
    demo(){
        std::cout<< "in no argument constructor" << std::endl;
        std::cout<< n1 << std::endl;
    }
    demo(int n1){
        this -> n1= n1;
        std::cout<< "in parameterized constructor" << std::endl;
        std::cout<< n1 << std::endl;
        //calling of demo constructor
        demo();
    }
    ~demo(){
        std::cout<< "in destructor" << std::endl;
    }
};

int main()
{
    demo obj1(50);
    std::cout<< "End main" << std::endl;
}