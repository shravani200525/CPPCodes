//destructor

#include<iostream>
class demo{
    public:
    //constructor
    demo(){
        std::cout<< "in no argument constructor" << std::endl;
    }
    //destructor
    ~demo(){
        std::cout<< "in destructor" << std::endl;
    }
};

int main()
{
    demo obj1;
    {
        demo obj2;
    }
    std::cout<< "End main" << std::endl;
}