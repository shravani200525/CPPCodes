#include<iostream>
class demo{
    int n1=100;
    int n2=200;
    public:
    //default argument
    demo(int n1,int n2=50){
        this->n1=n1;
        this->n2=n2;
        std::cout << "parameterized constructor" << std::endl;
    }
    void getinfo(){
        std::cout << n1 << std::endl;
        std::cout << n2 << std::endl;
    }
};

int main(){
    demo obj1(20);
    obj1.getinfo();
}