#include<iostream>
class demo{

    public:
    int n1=10;
    //no argument constructor
    demo()
    {
        std::cout<< "in no argument constructor" << std::endl;
    }
    //copy constructor
    demo(demo &obj){
        std::cout << "in copy constructor" << std::endl;
    }
    //member function
    void getinfo(){
        std::cout << n1 << std::endl; 
    }
};
int main()
{
    demo obj1; // it call the no argument constructor
    demo obj2(obj1); // it call the copy constructor

    obj1.getinfo();
    obj2.getinfo();

    //change the value of n1 in object 1
    //it will not change in the obj2

    obj1.n1 = 80;

    obj1.getinfo();
    obj2.getinfo();

    //it will change the value in the 2nd object
    //it will not change in the obj1

    obj2.n1=90;
    obj1.getinfo();
    obj2.getinfo();
}