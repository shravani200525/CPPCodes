//This Pointer

#include<iostream>

class demo{
    private:
        int n1=10;
        int n2=20;

    public:
        //constructor
        demo() //internally demo(demo *this)
        {
            std::cout << "no-argument constructor"<<std :: endl;
            std:: cout << this << std:: endl;
        }
        void getinfo() //getinfo(demo *this)
        {
            std:: cout<< this << std:: endl;
            std:: cout << this-> n1 << std:: endl;
            std:: cout << (*this).n2 << std:: endl;
        }
};

int main()
{
    demo *obj = new demo(){10,20};
    //demo *obj1 = new demo(10,20);
    //obj1->n1=10;
 
}