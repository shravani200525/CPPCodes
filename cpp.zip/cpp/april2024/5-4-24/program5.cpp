//This Pointer

#include<iostream>
//This Pointer
class demo{
    public:
        int n1=10;
        int n2=20;

    public:
        //constructor
        demo() //internally demo(demo *this)
        {
            std::cout << "no-argument constructor"<<std :: endl;
            std:: cout << this << std:: endl;
        }
        void getinfo() //getinfo(demo *this)
        {
            std:: cout<< this << std:: endl;
            std:: cout << this-> n1 << std:: endl;
            std:: cout << (*this).n2 << std:: endl;
        }
};

int main()
{
    //1st way to creating object
    demo obj;// demo(&obj)

    std:: cout << &obj << std:: endl;
    
    obj.getinfo(); //getinfo(&obj)
 
}