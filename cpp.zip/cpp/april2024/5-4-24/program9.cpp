#include<iostream>

class demo{
    //instance variable
    int mobile=10;

    //static variable

    static int tv;
    public:

    //non static function
    void getinfo()
    {
        int a=50;
        static int b=60;
        std:: cout<< mobile << std:: endl;
        std :: cout << tv << std:: endl;
        std :: cout << a << std:: endl;
        std :: cout << b << std:: endl;
    }
    //static function
    static void fun()
    {
        int a=70;
        static int b=90;
        //std:: cout<< mobile << std:: endl;
        std :: cout << tv << std:: endl;
        std :: cout << a << std:: endl; 
        std :: cout << b << std:: endl;
    }
};

int demo:: tv=20;

int main()
{
    demo obj;
    obj.getinfo();
    //obj.fun();

    demo::fun();
    demo::getinfo();
}