#include<iostream>

class demo{
   public:
      int n1;
      int n2;
};
int main()
{
   demo obj{10,20,30};
}
//error: too many initializers for ‘demo’