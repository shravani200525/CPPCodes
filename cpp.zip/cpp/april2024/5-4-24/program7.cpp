//static variable and instance variable

#include<iostream>

class demo
{
    //instance variable
    int mobile =10;

    //static variable
    //static int tv=20;//not possible to initialize 

    static int tv; //declaration

    //2nd way to initialize to static variable
    static const int tv1=30;

    //3rd way to initialize static variable
    static inline int tv2=40;

    //non static function

    public:
    void getinfo();    

};

//1st way to initialize static variable
int demo:: tv=20;

void demo:: getinfo()
{
    std:: cout << mobile << std:: endl;
    std:: cout << tv << std:: endl;
    std:: cout << tv1 << std:: endl;
    std:: cout << tv2 << std::endl;
}

int main()
{
    demo obj;
    obj.getinfo();
}