#include<iostream>

class demo{
    //instance variable
    int mobile=10;

    //static variable

    static int tv;
    public:

    //non static function
    void getinfo()
    {
        std:: cout<< mobile << std:: endl;
        std :: cout << tv << std:: endl;
    }
    //static function
    static void fun()
    {
        std:: cout<< mobile << std:: endl;
        std :: cout << tv << std:: endl;
    }
};

int demo:: tv=20;

int main()
{
    demo obj;
    obj.getinfo();
    obj.fun();
}