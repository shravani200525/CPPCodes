//static variable 
//-> cannot initialize the static variable inside the class
//->it can intialize outside the class with use of scope resoulution operator
//->it can only declare the static variable inside the class

#include<iostream>

class demo{
    public:
        static int n1; 
        int n2=20;

        void getinfo()
        {
            std::cout<<n1 << std::endl;
            std:: cout<< n2 << std::endl;
        }
};
int demo::n1=10;
int main()
{
    demo obj;
    obj.getinfo();
}