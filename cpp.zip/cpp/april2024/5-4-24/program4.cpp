#include<iostream>
//private variable initialization
class demo{
    //1st way
    public:
    int n1=20;
    public:
    void getinfo()
    {
        std:: cout << n1 << std::endl;
    }
};
int main(){
    //3rd way
    demo obj{30};
    //2nd way
    obj.n1=10;
    obj.getinfo();
}