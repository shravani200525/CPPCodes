#include<iostream>

//private variable initialization
class demo{
    //1st way
    int n1=10;
    public:
    void getinfo()
    {
        std:: cout << n1 << std::endl;
    }
};
int main(){
    //3rd way
    demo obj{10};//error
    //2nd way
    obj.n1=10;//error
    obj.getinfo();
}