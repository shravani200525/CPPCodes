#include<iostream>

class demo{
    public:
    //instance variable
    int mobile=10;

    //static variable

    static int tv;
    public:

    //non static function
    void getinfo()
    {
        std:: cout<< mobile << std:: endl;
        std :: cout << tv << std:: endl;
    }
};

int demo:: tv=20;

int main()
{
    demo obj1,obj2;
    obj1.getinfo();
    obj2.getinfo();

    //instance variable change
    obj1.mobile=700;
    obj1.getinfo();
    obj2.getinfo();
    
    
}