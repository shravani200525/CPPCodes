#include<iostream>

class demo{
    public:
    //instance variable
    char wing='A';

    //static variable

    static char grade;
    public:

    //non static function
    void getinfo()
    {
        int flatno = 101;
        static int flatno1 = 105;
        std:: cout<<  "the wing is=" << wing << std:: endl; //A
        std :: cout << "the grade is =" << grade << std:: endl; //B
        std:: cout << "the flat no is =" << flatno << std:: endl; //101
        std:: cout << "the flat no1 is =" << flatno1 << std:: endl; //105
    }
    //static function
    static void fun()
    {
        float tax = 500.00;
        static int taxno = 25;
        //std:: cout<< wing << std:: endl;
        std :: cout << "the grade is =" << grade << std:: endl;//B
        std:: cout << "the tax is  =" << tax << std:: endl;//500.00
        std :: cout << "the tax no is =" << taxno << std:: endl;//25
    }
};

char demo:: grade='B';

int main()
{
    demo obj1,obj2;
    obj1.getinfo();//
    obj2.fun();

}