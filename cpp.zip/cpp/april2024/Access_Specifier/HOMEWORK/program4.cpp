#include<iostream>
//1st class
class mobile{
    std:: string name = "iphone";
    std:: string model = "15pro";
    float price = 85000.00;
    int quantity = 2;

    public:
    //constructor

    mobile(){
        std:: cout<< "in the mobile constructor"<< std::endl;
    }
    //member function
    void getmobileinfo()
    {
        std:: cout << "name of the mobile is="<< name << std::endl <<std::endl;
        std:: cout << "model of the mobile is="<< model << std::endl <<std::endl;
        std:: cout << "price of the mobile is="<< price << std::endl <<std::endl;
        std:: cout << "quantity of the mobile is="<< quantity << std::endl <<std::endl;
    }
};

//2nd class
class Apps{
    std:: string name = "whatsapp";
    std:: string col = "green";
    float rating = 5.5;
    int noofchats = 101;

    public:
    //constructor

    Apps()
    {
        std::cout<<"in apps constructor"<< std::endl;
    }
    //member function
    void getAppsinfo()
    {
        std:: cout << "name of the App is="<< name << std::endl <<std::endl;
        std:: cout << "color of the App is="<< col << std::endl <<std::endl;
        std:: cout << "rating of the App is="<< rating << std::endl <<std::endl;
        std:: cout << "No of chats is="<< noofchats << std::endl <<std::endl;

        //creating object of the 1st class mobile
        mobile mob1;
        mob1.getmobileinfo();
    }
};

int main()
{
    //1st way
    //creating object of the 2nd class App
    Apps a1;
    a1.getAppsinfo();

    //2nd way
    Apps *a2 = new Apps();
    a2->getAppsinfo();
}