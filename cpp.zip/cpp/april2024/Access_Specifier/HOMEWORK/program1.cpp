//hya code madhi 2class create kelet ani 2nd class madhi 1st class cha object create kela ahe.

#include<iostream>

//1st class
class District
{
    std:: string dName = "pune";
    int dPopulation = 4;

    public:
        District(){ 
            std:: cout<< "in District constructor" << std:: endl;
           
        }
    void getDistrictinfo()
    {
        std:: cout<< dName << std:: endl;
        std:: cout << dPopulation << std:: endl;
    }
};

//2nd class

class State
{
    // instance variable
    std:: string sName = "maharashtra";
    int sPopulation = 14;

    public:
    // constructor -> no argument constructor

    State()
    {
        std:: cout << "In State Constructor" << std:: endl;
    }
    //member function
    void getStateinfo()
    {
        std:: cout<< sName << std:: endl;
        std:: cout << sPopulation << std:: endl;

        //creating object of District class
        District d1;
        d1.getDistrictinfo();

    }
};

int main()
{
    //object creation 1st way

    State s1;
    s1.getStateinfo();

    //object creation 2nd way

    State *s2 = new State();
    s2->getStateinfo();

    delete s2;

    //District d1;
    //d1.getDistrictinfo();

    return(0);
}
//op
// In State Constructor
// maharashtra
// 14
// in District constructor
// pune
// 4
// In State Constructor
// maharashtra
// 14
// in District constructor
// pune
// 4