#include<iostream>

//1st class

class company{
    std:: string Cname= "cctech";
    int post = 25;

    public:
    //constructor

    company()
    {
        std:: cout << "in company"<< std :: endl;
    }
    //member function

    void getcominfo()
    {
        std:: cout<< "name of the company:"<< Cname << std::endl;
        std:: cout<<"post of the company:"<< post << std::endl;
    }
};

//2nd class

class Manager
{
    std:: string Mname = "swaraj";
    int Mid = 10;
    float sal= 25000.00;

    public:
    //constructor

    Manager()
    {
        std:: cout<< "in manager constructor"<< std:: endl;
    }
    void getmaninfo()
    {
        std:: cout<< "name of the manager:" << Mname << std:: endl;
        std:: cout << "id of the manager:"<< Mid << std:: endl;
        std:: cout<< "salary of the manager:" << sal << std::endl;

        //creating object of the 1st class company

        //company co1;
        //co1.getcominfo();
    }
};

int main()
{
    //1st way to creating object 
    // creating object of 2nd class manager

    Manager m1;
    m1.getmaninfo();
    

    //2nd way to create object

    Manager *m2 = new Manager();
    m2->getmaninfo();

    //creating object of 1st class company

    //1st way 
    company co2;
    co2.getcominfo();

    //2nd way 
    company *co3 = new company();
    co3->getcominfo();
}