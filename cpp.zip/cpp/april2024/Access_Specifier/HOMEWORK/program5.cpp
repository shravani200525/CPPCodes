#include<iostream>

//1st class

class Hotel{
    std:: string Hname = "Lake Wood";
    int Hfloor = 3;

    public:
    //constructor

    Hotel()
    {
        std:: cout<< "in hotel constructor"<< std:: endl;
    }

    void getHinfo()
    {
        std:: cout << "name of the hotel=" << Hname<< std:: endl << std:: endl;
        std:: cout << "floor of the hotel=" << Hfloor<< std:: endl << std:: endl;
    }
};

//2nd class

class Menucard{
    std:: string category1 = "Nonveg";
    float price = 500.00;
    int noofdishes = 50;

    public:
    //constructor

     Menucard()
     {
         std:: cout<< "in Menucard constructor"<<std::endl;
     }

    void getMinfo()
    {
        std:: cout << "category =" << category1<< std:: endl << std:: endl;
        std:: cout << "price of each dish=" << price<< std:: endl << std:: endl;
        std:: cout << "no of dishes available in =" << noofdishes<< std:: endl << std:: endl;

        //creating object of 1st class Hotel

        Hotel h1;
        h1.getHinfo();
    }
};

int main()
{
    //1st way

    //creating object of 2nd class Menucard
    Menucard m1;
    m1.getMinfo();

    //2nd way
    Menucard *m2 = new Menucard();
    m2->getMinfo();
}