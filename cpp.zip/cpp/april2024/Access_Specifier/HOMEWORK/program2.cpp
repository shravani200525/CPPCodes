//real time example

#include<iostream>

//1st class
class mall{
    std:: string Mname = "amanora";
    int floor=4;

    public:
    //constructor
        mall(){
            std::cout<< "In mall constructor"<< std:: endl;
            
        }
    //member function
    void getmallinfo(){
        std::cout<< Mname << std:: endl;
        std:: cout<< floor << std:: endl;
    }
};

//2nd class
class section{
    std:: string Sname = "Kids Section";
    int gameprice = 500;

    public:
    //constructor

    section()
    {
        std:: cout<< "In section constructor"<< std:: endl;
    }

    //member function
    void getsectioninfo()
    {
        std:: cout << Sname << std:: endl;
        std:: cout << gameprice << std:: endl;

        //creating object of 1st class mall
        mall m3;
        m3.getmallinfo();
    }
};


int main(){
    //1st way of creating object

    section s1;
    s1.getsectioninfo();

    //2nd way of creating object


    section *s2 = new section();
    s2->getsectioninfo();
    delete s2;
}

// In section constructor
// Kids Section
// 500
// In mall constructor
// amanora
// 4
// In section constructor
// Kids Section
// 500
// In mall constructor
// amanora
// 4