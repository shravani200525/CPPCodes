#include<iostream>

class  demo
{
    private:
        int a =10;
    public:
        void getinfo(); //hith fkt declare kel ahe ani class chya baher tyachi body
        
};

void demo:: getinfo() 
{
    std:: cout << a << std:: endl;
}

int main()
{
    demo obj;
    obj.getinfo();
}

//10