#include<iostream>

class demo{
    private: 
        int a=10;
    public: 
        int b=20;
    protected: 
        int c=30;

    void getinfo() //error because this  fun is protected and this is not access main fun
    {
        std:: cout << a << b << c << std:: endl;
    }
};

int main()
{
    demo obj;
    obj.getinfo();
}

//error: ‘void demo::getinfo()’ is protected within this context