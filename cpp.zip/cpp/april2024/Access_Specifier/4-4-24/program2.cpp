// Access Specifier
//public protected  private

#include<iostream>

class demo 
{
    int a=10; // by default private -> it can access only in the class and friend fun

    protected: //it can access in friend fun and child class
        int b=20;
    
    public: //it can access everywhere
        int c=30;

    void getinfo()
    {
        std:: cout<< a << b << c << std:: endl;
    }
};

int main()
{

    demo obj;
    obj.getinfo();

    std:: cout<< obj.a << obj.b << obj.c << std:: endl; 
    //there is error because we try to access private and protected member outside the class
                                                        
}