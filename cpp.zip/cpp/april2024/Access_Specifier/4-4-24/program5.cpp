#include<iostream>

class demo
{
    private:
        int n1;
    public:
        void getinfo()
        {
            std::cout<< n1 << std::endl;
        }
};

int main()

{
    demo obj;
    obj.n1=10;
    obj.getinfo();
}
// error: ‘int demo::n1’ is private within this context