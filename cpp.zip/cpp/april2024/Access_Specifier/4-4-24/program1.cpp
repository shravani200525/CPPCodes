//default constructor 

#include<iostream>

class demo
{
    int x=10;
    int y=20;
    public:
        demo() //internally demo (&obj) by default
        {
            std:: cout<< "in constructor" << std:: endl;
        }
        void getinfo()
        {
            std:: cout<< x << std:: endl;
            std:: cout << y << std:: endl;
        }
};

int main()
{
    // 1st way to creating object

    demo obj; // calling demo(&obj)
    obj.getinfo(); // calling getinfo(&obj)

    //2nd way to creating object

    demo *obj2= new demo(); // demo (obj2)
    obj2->getinfo();// getinfo(obj2)
}
//output
// in constructor
// 10
// 20
// in constructor
// 10
// 20