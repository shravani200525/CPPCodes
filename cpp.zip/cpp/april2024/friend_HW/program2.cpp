//2nd scenario
#include<iostream>
#include<string.h>
class emp2;
class emp1{
    private:
        int empid = 11;
    protected:
        char ename[20] = "sharad";
    public:
        emp1(){
            std:: cout << "in no argument constructor" << std::endl;
        }
   void getinfo(){
    std:: cout << empid << std:: endl;
    std:: cout << ename << std:: endl;
    }
    void mul(){
        int a = 2;
        int b = 2;
        int ans;
        ans = a*b;
        std:: cout<<a << std:: endl;
        std:: cout << b << std:: endl;
        std:: cout << "multiplication=" << ans << std:: endl;
    }
    friend void getdetails(emp1 &obj,emp2 &obj1);

};

class emp2{
       private:
        int eid= 12;
    protected:
        char ename[20] = "karan";
    public:
        emp2(){
            std:: cout << "in no argument constructor" << std::endl;
        }
   void getinfor(){
    std:: cout << eid << std:: endl;
    std:: cout << ename << std:: endl;
    }
    friend void getdetails(emp1 &obj,emp2 &obj1);
};
void getdetails(emp1 &obj,emp2 &obj1)
{
    obj.getinfo();
    obj1.getinfor();
    obj.mul();
}

int main(){
    emp1 obj2;
    emp2 obj3;
    getdetails(obj2,obj3);
}