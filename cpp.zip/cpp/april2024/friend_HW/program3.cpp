//3rd scenario
#include<iostream>
#include<string.h>
class two;
class one{
    private:
        int rno = 31;
        char name[20] = "shravani";
    protected:
        float marks = 85.76;
    public:
        one(){
            std:: cout << "no argument"<<std:: endl;
        }
    void getinfo(){
        std:: cout << rno << std::endl;
        std :: cout << name << std::endl;
        std:: cout <<  marks << std::endl;
    }
    void addition(){
        int ans;
        int a = 20;
        int b = 30;
        ans = a+ b;
        std:: cout << "a=" << a << std::endl;
        std :: cout << "b=" << b << std::endl;
        std:: cout <<  "addition of two no=:" << ans << std::endl;
    }
  friend class two;  
};
class two{
    public:
        void getinfor(one &obj)
        {
            obj.getinfo();
            obj.addition();
        }
};

int main(){
    one obj1;
    two obj2;
    obj2.getinfor(obj1);
}