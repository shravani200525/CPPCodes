//1st scenario
#include<iostream>
class Friend{
    private:
        int a=10;
    protected:
        int b = 20;
    public:
        Friend(){
            std::  cout << "in no argument constructor" << std::  endl;
        }
    void getinfor(){
        std::cout << a << std ::endl;
        std:: cout << b << std:: endl;
    }
    friend void addition(Friend &obj);
};

void addition(Friend &obj){
    int ans;
    ans = obj.a + obj.b;
    std:: cout<< obj.a << std:: endl;
    std:: cout << obj.b << std::endl;
    std:: cout << "Addition="<<ans<< std::endl;
}
int main(){
    Friend obj1;
    //obj1.getinfor();
    addition(obj1);
}