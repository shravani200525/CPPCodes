#include<iostream>
class demo{
    public:
    //no argument constructor
    demo()
    {
        
        std:: cout << "no argument constructor"<< std::endl;
    }

    //parameter constructor
    demo(int a)
    {
        this();
        std:: cout<< "parameterized constructor" << std::endl;
    }

    //copy constructor
    demo (demo& obj)
    {
        std:: cout << "copy constructor" << std::endl;
    }
    
};

int main()
{
    demo obj1;
    demo obj2(10);
    demo obj3(obj1);
}