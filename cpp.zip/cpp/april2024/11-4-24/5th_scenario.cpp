//5th scenario of copy constructor
//by using array
#include<iostream>
class demo{
    public:
    //no argument constructor
    demo()
    {
        std::cout<< "no argument constructor" << std:: endl; 
    }
    //parameterized constructor
    demo(int n1)
    {
        std:: cout << "parameterized constructor" << std:: endl;
    }
    //copy constructor
    demo(demo& obj){
        std:: cout << "copy constructor" << std::endl;
    }
};
int main()
{
    demo obj1;
    demo obj2;
    demo obj3;
    demo obj4;

    //5th scenario
    demo arr[] = {obj1,obj2,obj3,obj4};
    //internally
    //demo arr[0]= obj1;
    //demo arr[1]= obj2;
    //demo arr[2]= obj3;
    //demo arr[3]= obj4;
}