#include<iostream>

class demo{
    public:
    //no argument constructor
    demo(){
        demo obj1(10); //calling parameter
        demo obj2(obj1); // calling copy
        std::cout<< "no argument constructor" << std::endl;
    }

    //parameter constructor
    demo (int a){
        std:: cout << "paramterized constructor" << std :: endl;
    }

     //copy constructor
    demo (demo& obj)
    {
        std:: cout << "copy constructor" << std::endl;
    }
};

int main()
{
    demo obj3;
    demo obj4(10);
    demo obj5(obj3);
}