#include<iostream>
class demo
{
    public:
    //no argument constructor
    demo()
    {
        std:: cout << "no argument constructor" << std:: endl;
    }

    //parameter constructor
    demo (int a){
        std:: cout << "parameterized constructor" << std::endl;
        std:: cout << a << std::endl;
    }
    
    //copy constructor
    demo (demo& obj)
    {
        std:: cout << "copy constructor" << std::endl;
    }
};

int main()
{
    //object creating for no argument constructor
    demo obj1;

    //object creating for parameter constructor
    demo obj3(10);

    //object creating for copy constructor
    demo obj2=obj3;
}