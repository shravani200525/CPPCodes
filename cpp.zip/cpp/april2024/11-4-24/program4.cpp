#include<iostream>
class demo{
    public:
    //no argument constructor
    demo()
    {
        demo(10); //It calling to parameter constructor
        std:: cout << "no argument constructor"<< std::endl;
    }

    //parameter constructor
    demo(int a)
    {
    
        std:: cout<< "parameterized constructor" << std::endl;
    }

    //copy constructor
    demo (demo& obj)
    {
        std:: cout << "copy constructor" << std::endl;
    }
    
};

int main()
{
    demo obj1;
    demo obj2(10);
    demo obj3(obj1);
}