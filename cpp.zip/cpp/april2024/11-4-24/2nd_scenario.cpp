//2nd scenario of copy constructor

#include<iostream>

class demo{
    public:
    //no argument constructor
    demo()
    {
        //call parameter constructor
        demo obj1(10);

        //2nd scenario
        //call copy constructor
        demo obj2(obj1);

        std:: cout << "no argument constructor" << std:: endl;
    }
    //parameter constructor
    demo(int a)
    {
        std:: cout << "parameterized constructor" << std:: endl;
    }
    //copy constructor
    demo(demo& obj)
    {
        std:: cout << "copy constructor"<< std:: endl;
    }
};

int main()
{
    //creating object for no argument constructor
    demo obj3;
    //creating object for parameter constructor
    demo obj4(20);
    //creating object for copy constructor
    demo obj5(obj4);
}