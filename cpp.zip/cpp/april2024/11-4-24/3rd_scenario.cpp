//3rd scenario of copy constructor

#include<iostream>
class demo{
    public:
    int n1=10;
    int n2=20;

    demo(int a,int b)
    {
        std:: cout << a << std:: endl;
        std:: cout << b << std :: endl;
    }

    //3rd scenario
    void info (demo obj){

    }
    demo(demo& obj)
    {
        std:: cout << "copy constructor" <<std ::endl;
    }
};
int main()
{
    demo obj1(100,200);

    //calling copy constructor
    obj1.info(obj1);
}