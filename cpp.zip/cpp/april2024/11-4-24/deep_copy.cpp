//deep copy constructor
#include<iostream>
class demo{
    public:
    int x = 10;
    int y = 20;

    demo(){
        std:: cout << "no argument constructor" << std:: endl;
        std:: cout << x << std:: endl;
        std:: cout << y << std:: endl;
    }

    //copy constructor
    demo(demo& obj){
        std:: cout << "copy constructor" << std:: endl;
    }
};

int main()
{
    demo obj1;

    demo obj2(obj1);
    int x,y;
    obj1.x = 50;
    std:: cout << obj1.x << std:: endl;
    std:: cout << obj1.y << std:: endl;

    obj2.y = 70;
    std:: cout << obj2.x << std:: endl;
    std:: cout << obj2.y << std:: endl;
}