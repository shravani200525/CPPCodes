//structure in cpp

#include<iostream>

struct demo
{
    int n1=10;
    int &n2=n1;
};

int main()
{
    demo obj;
    std:: cout<< sizeof(obj) << std:: endl;
    std:: cout<< sizeof(struct demo)<< std:: endl;
    return(0);
}