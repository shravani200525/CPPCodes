//variable

#include<iostream>

class demo{
    int x=10,y=20;
    public:
        void fun()
        {
            std:: cout<< x << std:: endl;
            std:: cout<< y << std:: endl;
        }
        //constructor

        demo()
        {
            std:: cout << "in demo constructor:" <<std:: endl;
        }
};

int main()
{
    //1st way to creating object
    // memory allocate on the stack
    demo obj;
    obj.fun();

    //2nd way to creating object
    // memory allocate on the heap

    demo *obj2= new demo(); // new is internally malloc
    obj2->fun();
    (*obj2).fun();

    delete obj2; // interally its work as a free
    return(0);
}