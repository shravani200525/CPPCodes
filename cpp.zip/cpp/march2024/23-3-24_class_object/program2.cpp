//constructor
//->by default public
//->it also called no argument constructor and default constructor
//->it use to initialize instance variable

#include<iostream>

class demo{
    int x=10;
    int y=20;
    public:
        demo()  //constructor
        {

        }
        void fun()
        {
            std:: cout << x << std:: endl;
            std:: cout<< y << std:: endl;
        }
};

int main()
{
    demo obj;
    //std:: cout <<obj.x << std:: endl;

    obj.fun();
    return(0);
}