#include<iostream>


void fun(int n1,int n2){ // error: call of overloaded ‘fun(int&, int&)’ is ambiguous

}
void fun(int &n1,int &n2)
{
    int temp=n1;
    n1=n2;
    n2=temp;
    std:: cout<< n1 << " "<< n2 << std:: endl;
}

int main()
{
    int n1=10;
    int n2=20;

    fun(n1,n2);
    std:: cout<< n1 << " " << n2 << std:: endl;
    return(0);
}