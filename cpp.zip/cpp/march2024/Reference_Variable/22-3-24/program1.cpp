//reference variable
//->reference variable internally pointer ahe.

#include<iostream>

int main()
{
    int n1=10;
    int &n2=n1;//internally int *n2= &n1;
    int *ptr = &n1;

    std::cout<< n1 << std:: endl; //10
    std:: cout << n2 << std:: endl; //10  // internally std:: cout<< *n2 << std:: endl;

    std:: cout<< ptr << std::endl; //0x7fff220f7b34 address of ptr

    // printing size

    std:: cout<< sizeof(n1) << std:: endl; //4
    std:: cout<< sizeof(n2) << std:: endl; // 4 //internally std:: cout<< sizeof(*n2) << std:: endl;
    std:: cout<< sizeof(ptr) << std:: endl; //8 byte because it is pointer

    // printing address

    std:: cout<< &n1 << std:: endl; //0x7fff220f7b34
    //n1 and n2 cha address same ahe

    std:: cout << &n2 << std:: endl; // 0x7fff220f7b34    //internally std::cout<< *n2 << std:: endl;
    std:: cout << &ptr << std:: endl; //0x7fff220f7b38 address
}