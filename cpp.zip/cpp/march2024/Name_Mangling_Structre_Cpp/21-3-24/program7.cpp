#include<iostream>

class investor{
    char iName[20]="shravani";
    float investment=89.22;
    
    public:
    void getinvestmentdetails()
    {
        std:: cout << iName << std:: endl;
        std:: cout << investment << std:: endl;
    }
};

int main()
{
    investor obj;

    int x=10;
    std:: cout<< x << std:: endl;
    std:: cout << obj << std:: endl; //error cannot print object like this
    return(0);
}
// error: no match for ‘operator<<’ (operand types are ‘std::ostream’ {aka ‘std::basic_ostream<char>’} and ‘investor’)