//name mangling -> jr eka code madhi same name che 2-3 fun astil tr compiler tyala compile time tya fun ch name change krto
#include<iostream>

void fun( int n1,int n2) //internally void funii (int n1,int n2) funii because we pass 2integer
{
    std:: cout<< "int-int" << n1 << n2 << std:: endl;
}

void fun(int n1,float n2) //internally void funif (int n1,float n2) funif because we pass 1integer & 1float
{
    std:: cout<< "int-float" << n1 << n2 << std:: endl;
}

void fun(float n1,float n2) ////internally void funff (float n1,float n2) funff because we pass 2float
{

   std:: cout<< "float-float" << n1 << n2 << std:: endl;
}

int main()
{

    fun(10,20); //int-int1020
    fun(10,10.4f); //int-float1010.4
    fun(10.5f,10.5f); //float-float10.510.5
//  fun(11.4,11.4);
}
// error: call of overloaded ‘fun(double, double)’ is ambiguous