//name mangling

#include<stdio.h>

int fun(int n1,int n2)
{
    return(n1+n2); //30
}

int fun(int n1,int n2,int n3)
{
    return(n1+n2+n3); //60
}

void main()
{
    printf("%d\n",fun(10,20));
    printf("%d\n",fun(10,20,30));

    return(0);
}
//error conflict type for int
