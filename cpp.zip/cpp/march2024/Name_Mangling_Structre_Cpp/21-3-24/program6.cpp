#include<iostream>

class investor{
    char iName[20]="shravani";
    float investment=89.22;
    
    public:
    void getinvestmentdetails()
    {
        std:: cout << iName << std:: endl;
        std:: cout << investment << std:: endl;
    }
};

int main()
{
    investor obj;

    obj.getinvestmentdetails();
    return(0);
}
//shravani
// 89.22