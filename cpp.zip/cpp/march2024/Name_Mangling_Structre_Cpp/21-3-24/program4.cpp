//STRUCTURE IN C++
// ->cpp madhi structure la initialize nhi kru shkt
//-> structure is by default public
//-> structure madhi object create karayla struct keyword use krtat

#include<iostream>

struct investor
{
    char iName[20]="shravani";
    float investment = 50.32;

    void getinvestmentdetails()
    {
        std:: cout<< iName << std:: endl;
        std:: cout << investment << std:: endl;
    }
};

int main()
{
    // investor obj;

    struct investor obj;

    obj.getinvestmentdetails();
    return(0);
}
// shravani
// 50.32