//Name mangling

#include<iostream>

void fun(int n)
{
    std::cout<< n << std:: endl;

}

int main()
{
    std::cout<< fun(10)<< std::endl;
}
//error: no match for ‘operator<<’ (operand types are ‘std::ostream’ {aka ‘std::basic_ostream<char>’} and ‘void’)