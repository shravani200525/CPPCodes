// Class

#include<iostream>

class investor
{
    char iName[20]="shravani";
    float investment=50.32;

    public:    
    void getinvestmentdetails()
    {
        std:: cout << iName << std:: endl;
        std:: cout << investment << std:: endl;
    }
};

int main()
{
    investor obj;

    std:: cout << obj.iName << std:: endl; //error cannot access private variable

    obj.getinvestmentdetails();
    return(0);
}