#include<iostream>

int main()
{
    const int n1=10;
    std::cout<< n1 << std:: endl;
    n1=20;
    std:: cout << n1 << std:: endl;
    return(0);
}
//error: assignment of read-only variable ‘n1’