#include<iostream>

int main()
{
    int n1=10;
    int n2=20;
    std::cout << n1 << std:: endl;
    std::cout << n2 << std:: endl;
    const int *ptr=&n1; //pointer madhe value const krta yet nhi
    std::cout << *ptr << std:: endl;
    ptr=&n2;
    std::cout << *ptr << std:: endl;
}