#include<iostream>

#define x 100
#define mul(x,y) x*y

int main()
{
    int n2=10;
    std:: cout<< x << std:: endl;
    std:: cout<< n2 << std::endl;

    int n1=10;
    int n3=5;
    std:: cout<< mul (n1,n3) << std::endl;
    return (0);
}