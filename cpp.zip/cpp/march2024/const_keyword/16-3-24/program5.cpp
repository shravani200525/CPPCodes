#include<iostream>

#define x 100

int main()
{
    int n2=10;
    std:: cout<< x << std:: endl;
    std:: cout<< n2 << std::endl;
    return (0);
}