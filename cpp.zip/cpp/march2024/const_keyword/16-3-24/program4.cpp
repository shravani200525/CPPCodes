#include<iostream>
int main()
{
    int n1=10;

    std:: cout<< n1<< std::endl;

    const int *ptr = &n1; //error because value 10 const zali & hyachya mul.
    std:: cout<< *ptr << std::endl;
    *ptr =200; //error
}
//error: assignment of read-only location ‘* ptr’