#include<iostream>

void fun();
int main()
{
    fun();

}

void fun()
{
    std::cout<<"in fun"<<std::endl;
}