#include<iostream>

int main()
{
    int cout=10;//implicit cout
    std::cout<<cout<<std::endl;//explicit cout
}