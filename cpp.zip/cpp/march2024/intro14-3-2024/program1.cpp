#include<iostream>

int main()
{
    std::cout<<"welcome to c++"<<std::endl;
    return(0);
}
//welcome to c++