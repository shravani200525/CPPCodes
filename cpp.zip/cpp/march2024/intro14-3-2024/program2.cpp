#include<iostream>

void fun();
int main()
{
    fun();
}
// error: ld returned 1 exit status