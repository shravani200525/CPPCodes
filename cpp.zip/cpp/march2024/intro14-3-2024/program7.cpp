#include<iostream>

using namespace std;

int main()
{
    int cout=10;
    cout<<cout<<endl; //std nhi use kel mhnun
    return(0);
}
// error: invalid operands of types ‘int’ and ‘<unresolved overloaded function type>’ to binary ‘operator<<’