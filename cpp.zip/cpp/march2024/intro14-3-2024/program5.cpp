#include<iostream>

static void fun()
{
    std::cout<<"in fun"<<std::endl;
}